#!/bin/bash
set -e

source ~/neu-venv/bin/activate

COMMON="--scale 150m --batch_size 16 --max_steps 20000 --dtype bfloat16 --save_dir checkpoints"
LOGDIR=~/logs
mkdir -p "$LOGDIR" ~/checkpoints

echo "========================================"
echo "Neu Phase 0: Baseline Training Runs"
echo "Config: 150M scale, 2x RTX 5000 Ada DDP"
echo "  batch_size=16/gpu, grad_accum=4, seq_len=2048"
echo "  effective_batch=128, tokens/step=262,144"
echo "  max_steps=20,000, total_tokens≈5.2B"
echo "========================================"
echo ""

# transformer already complete — skip
for model in mamba2 neu fixed_hybrid; do
    EXTRA=""
    if [ "$model" = "neu" ]; then
        EXTRA="--batch_size 24 --gradient_accumulation_steps 2"
    fi

    echo "=== Starting $model at $(date) ==="
    torchrun --nproc_per_node=2 -m neu.train \
        --model "$model" $COMMON $EXTRA \
        2>&1 | tee "${LOGDIR}/${model}_150m.log"
    echo "=== Finished $model at $(date) ==="
    echo ""
done

echo "All baseline runs complete at $(date)"
