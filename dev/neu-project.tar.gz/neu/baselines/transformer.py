"""Pure transformer baseline — standard pre-norm causal transformer."""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint as grad_checkpoint
from typing import Optional, Dict, Any

from neu.model.block import RMSNorm, _HAS_FLASH_ATTN

if _HAS_FLASH_ATTN:
    from flash_attn import flash_attn_func


class TransformerBlock(nn.Module):
    def __init__(self, d_model: int, n_heads: int, dropout: float = 0.0, norm_eps: float = 1e-6):
        super().__init__()
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.norm1 = RMSNorm(d_model, eps=norm_eps)
        self.norm2 = RMSNorm(d_model, eps=norm_eps)
        self.qkv = nn.Linear(d_model, 3 * d_model, bias=False)
        self.out_proj = nn.Linear(d_model, d_model, bias=False)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, 4 * d_model),
            nn.GELU(),
            nn.Linear(4 * d_model, d_model),
        )
        self.dropout = dropout

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, D = x.shape

        h = self.norm1(x)
        qkv = self.qkv(h).reshape(B, T, 3, self.n_heads, self.head_dim)
        q, k, v = qkv.unbind(dim=2)
        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)

        drop_p = self.dropout if self.training else 0.0

        if _HAS_FLASH_ATTN and x.is_cuda:
            q_fa = q.transpose(1, 2)
            k_fa = k.transpose(1, 2)
            v_fa = v.transpose(1, 2)
            attn_out = flash_attn_func(
                q_fa, k_fa, v_fa,
                dropout_p=drop_p,
                causal=True,
            ).reshape(B, T, D)
        else:
            attn_out = F.scaled_dot_product_attention(
                q, k, v, is_causal=True, dropout_p=drop_p,
            ).transpose(1, 2).reshape(B, T, D)

        x = x + self.out_proj(attn_out)
        x = x + self.ffn(self.norm2(x))
        return x


class TransformerModel(nn.Module):
    def __init__(self, d_model: int = 768, n_layers: int = 12, n_heads: int = 12,
                 vocab_size: int = 32000, max_seq_len: int = 2048,
                 dropout: float = 0.0, norm_eps: float = 1e-6):
        super().__init__()
        self.tok_emb = nn.Embedding(vocab_size, d_model)
        self.pos_emb = nn.Embedding(max_seq_len, d_model)
        self.drop = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        self.blocks = nn.ModuleList([
            TransformerBlock(d_model, n_heads, dropout, norm_eps)
            for _ in range(n_layers)
        ])
        self.norm_f = RMSNorm(d_model, eps=norm_eps)
        self.lm_head = nn.Linear(d_model, vocab_size, bias=False)
        self.lm_head.weight = self.tok_emb.weight
        self._gradient_checkpointing = False
        self.apply(self._init_weights)

    def _init_weights(self, module: nn.Module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, input_ids: torch.Tensor, targets: Optional[torch.Tensor] = None,
                **kwargs) -> Dict[str, Any]:
        B, T = input_ids.shape
        pos = torch.arange(T, device=input_ids.device).unsqueeze(0)
        x = self.drop(self.tok_emb(input_ids) + self.pos_emb(pos))
        for block in self.blocks:
            if self._gradient_checkpointing and self.training:
                x = grad_checkpoint(block, x, use_reentrant=False)
            else:
                x = block(x)
        x = self.norm_f(x)
        logits = self.lm_head(x)
        result = {"logits": logits}
        if targets is not None:
            result["loss"] = nn.functional.cross_entropy(
                logits.view(-1, logits.size(-1)), targets.view(-1), ignore_index=-1
            )
            result["ce_loss"] = result["loss"]
        return result

    def param_count(self) -> int:
        return sum(p.numel() for p in self.parameters())

    def enable_gradient_checkpointing(self, enable: bool = True):
        self._gradient_checkpointing = enable

    @classmethod
    def from_config(cls, config) -> "TransformerModel":
        return cls(
            d_model=config.d_model, n_layers=config.n_layers, n_heads=config.n_heads,
            vocab_size=config.vocab_size, max_seq_len=config.max_seq_len,
            dropout=config.dropout, norm_eps=config.norm_eps,
        )
