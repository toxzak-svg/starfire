"""Pure Mamba-2 baseline — no attention, no routing."""

import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint as grad_checkpoint
from typing import Optional, Dict, Any

from neu.model.block import RMSNorm, SSMLayer


class Mamba2Block(nn.Module):
    def __init__(self, d_model: int, d_ssm_state: int = 64, expand: int = 2,
                 conv_size: int = 4, norm_eps: float = 1e-6):
        super().__init__()
        self.norm = RMSNorm(d_model, eps=norm_eps)
        self.ssm = SSMLayer(d_model, d_state=d_ssm_state, expand=expand, conv_size=conv_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.ssm(self.norm(x))


class Mamba2Model(nn.Module):
    def __init__(self, d_model: int = 768, n_layers: int = 12, vocab_size: int = 32000,
                 d_ssm_state: int = 64, ssm_expand: int = 2, ssm_conv_size: int = 4,
                 dropout: float = 0.0, norm_eps: float = 1e-6):
        super().__init__()
        self.tok_emb = nn.Embedding(vocab_size, d_model)
        self.drop = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        self.blocks = nn.ModuleList([
            Mamba2Block(d_model, d_ssm_state, ssm_expand, ssm_conv_size, norm_eps)
            for _ in range(n_layers)
        ])
        self.norm_f = RMSNorm(d_model, eps=norm_eps)
        self.lm_head = nn.Linear(d_model, vocab_size, bias=False)
        self.lm_head.weight = self.tok_emb.weight
        self._gradient_checkpointing = False
        self.apply(self._init_weights)

    def _init_weights(self, module: nn.Module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, input_ids: torch.Tensor, targets: Optional[torch.Tensor] = None,
                **kwargs) -> Dict[str, Any]:
        x = self.drop(self.tok_emb(input_ids))
        for block in self.blocks:
            if self._gradient_checkpointing and self.training:
                x = grad_checkpoint(block, x, use_reentrant=False)
            else:
                x = block(x)
        x = self.norm_f(x)
        logits = self.lm_head(x)
        result = {"logits": logits}
        if targets is not None:
            result["loss"] = nn.functional.cross_entropy(
                logits.view(-1, logits.size(-1)), targets.view(-1), ignore_index=-1
            )
            result["ce_loss"] = result["loss"]
        return result

    def param_count(self) -> int:
        return sum(p.numel() for p in self.parameters())

    def enable_gradient_checkpointing(self, enable: bool = True):
        self._gradient_checkpointing = enable

    @classmethod
    def from_config(cls, config) -> "Mamba2Model":
        return cls(
            d_model=config.d_model, n_layers=config.n_layers, vocab_size=config.vocab_size,
            d_ssm_state=config.d_ssm_state, ssm_expand=config.ssm_expand,
            ssm_conv_size=config.ssm_conv_size, dropout=config.dropout, norm_eps=config.norm_eps,
        )
