"""
Fixed hybrid baseline — Jamba-style interleaving.
Every Nth layer is attention, the rest are SSM. No learned routing.
"""

import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint as grad_checkpoint
from typing import Optional, Dict, Any

from neu.model.block import RMSNorm, SSMLayer, LocalAttention


class FixedHybridBlock(nn.Module):
    def __init__(self, d_model: int, n_heads: int, d_ssm_state: int = 64,
                 ssm_expand: int = 2, ssm_conv_size: int = 4,
                 attn_window_size: int = 512, use_attention: bool = False,
                 dropout: float = 0.0, norm_eps: float = 1e-6):
        super().__init__()
        self.use_attention = use_attention
        self.norm = RMSNorm(d_model, eps=norm_eps)
        if use_attention:
            self.layer = LocalAttention(d_model, n_heads, attn_window_size, dropout)
        else:
            self.layer = SSMLayer(d_model, d_ssm_state, ssm_expand, ssm_conv_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.layer(self.norm(x))


class FixedHybridModel(nn.Module):
    """Attention every `attn_every` layers, SSM everywhere else."""

    def __init__(self, d_model: int = 768, n_layers: int = 12, n_heads: int = 12,
                 vocab_size: int = 32000, attn_every: int = 6,
                 d_ssm_state: int = 64, ssm_expand: int = 2, ssm_conv_size: int = 4,
                 attn_window_size: int = 512, dropout: float = 0.0, norm_eps: float = 1e-6):
        super().__init__()
        self.tok_emb = nn.Embedding(vocab_size, d_model)
        self.drop = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        self.blocks = nn.ModuleList([
            FixedHybridBlock(
                d_model, n_heads, d_ssm_state, ssm_expand, ssm_conv_size,
                attn_window_size,
                use_attention=((i + 1) % attn_every == 0),
                dropout=dropout, norm_eps=norm_eps,
            )
            for i in range(n_layers)
        ])
        self.norm_f = RMSNorm(d_model, eps=norm_eps)
        self.lm_head = nn.Linear(d_model, vocab_size, bias=False)
        self.lm_head.weight = self.tok_emb.weight
        self._gradient_checkpointing = False
        self.apply(self._init_weights)

    def _init_weights(self, module: nn.Module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, input_ids: torch.Tensor, targets: Optional[torch.Tensor] = None,
                **kwargs) -> Dict[str, Any]:
        x = self.drop(self.tok_emb(input_ids))
        for block in self.blocks:
            if self._gradient_checkpointing and self.training:
                x = grad_checkpoint(block, x, use_reentrant=False)
            else:
                x = block(x)
        x = self.norm_f(x)
        logits = self.lm_head(x)
        result = {"logits": logits}
        if targets is not None:
            result["loss"] = nn.functional.cross_entropy(
                logits.view(-1, logits.size(-1)), targets.view(-1), ignore_index=-1
            )
            result["ce_loss"] = result["loss"]
        return result

    def param_count(self) -> int:
        return sum(p.numel() for p in self.parameters())

    def enable_gradient_checkpointing(self, enable: bool = True):
        self._gradient_checkpointing = enable

    @classmethod
    def from_config(cls, config) -> "FixedHybridModel":
        return cls(
            d_model=config.d_model, n_layers=config.n_layers, n_heads=config.n_heads,
            vocab_size=config.vocab_size, d_ssm_state=config.d_ssm_state,
            ssm_expand=config.ssm_expand, ssm_conv_size=config.ssm_conv_size,
            attn_window_size=config.attn_window_size, dropout=config.dropout,
            norm_eps=config.norm_eps,
        )
