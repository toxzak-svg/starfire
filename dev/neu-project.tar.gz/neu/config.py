from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ModelConfig:
    # Architecture
    d_model: int = 768
    n_layers: int = 12
    n_heads: int = 12
    vocab_size: int = 32000
    max_seq_len: int = 2048
    dropout: float = 0.0

    # SSM
    d_ssm_state: int = 64
    ssm_expand: int = 2
    ssm_conv_size: int = 4

    # Attention
    attn_window_size: int = 512

    # Cheap path
    cheap_ratio: int = 4  # hidden dim = d_model // cheap_ratio

    # Router
    n_paths: int = 3
    gate_temperature: float = 1.0
    load_balance_weight: float = 0.01

    # Persistent state
    d_persistent_state: int = 64
    use_persistent_state: bool = True

    # RMSNorm
    norm_eps: float = 1e-6

    @property
    def d_cheap_hidden(self) -> int:
        return self.d_model // self.cheap_ratio

    @property
    def head_dim(self) -> int:
        return self.d_model // self.n_heads


@dataclass
class TrainConfig:
    # Data
    dataset: str = "HuggingFaceFW/fineweb-edu-score-2"
    tokenizer: str = "mistralai/Mistral-7B-v0.1"
    seq_len: int = 2048

    # Training
    batch_size: int = 32
    gradient_accumulation_steps: int = 4
    max_steps: int = 50_000
    warmup_steps: int = 500  # Shorter warmup so we don't lag Mamba2's aggressive initial descent
    lr: float = 3e-4
    min_lr: float = 3e-5
    weight_decay: float = 0.1  # FineWeb-Edu is high-quality; stronger decay encourages generalizable patterns
    grad_clip: float = 1.0
    betas: tuple = (0.9, 0.95)

    # Temperature annealing (Phase 3)
    anneal_temp: bool = False
    anneal_start_step: int = 40_000
    anneal_end_step: int = 50_000
    anneal_final_temp: float = 0.1

    # Eval
    eval_interval: int = 1000
    eval_steps: int = 50
    log_interval: int = 50  # Less frequent logging avoids W&B sync blocking the training loop (Step 320 cliff)

    # Checkpoints
    save_interval: int = 5_000
    save_dir: str = "checkpoints"

    # Logging
    wandb_project: str = "neu"
    wandb_run: Optional[str] = None
    wandb_offline: bool = True  # Avoid sync blocking; upload later with wandb sync

    # Hardware
    num_workers: int = 4  # Prefetch/decompress FineWeb shards so GPU isn't starved
    dtype: str = "bfloat16"
    compile: bool = True
    gradient_checkpointing: bool = False
    device: str = "cuda"


# --- Preset configs at different scales ---

CONFIGS = {
    "150m": ModelConfig(
        d_model=768,
        n_layers=12,
        n_heads=12,
        vocab_size=32000,
        max_seq_len=2048,
    ),
    "350m": ModelConfig(
        d_model=1024,
        n_layers=24,
        n_heads=16,
        vocab_size=32000,
        max_seq_len=2048,
    ),
    "1b": ModelConfig(
        d_model=2048,
        n_layers=24,
        n_heads=16,
        vocab_size=32000,
        max_seq_len=2048,
    ),
}


def get_config(scale: str = "150m", **overrides) -> ModelConfig:
    cfg = CONFIGS[scale]
    for k, v in overrides.items():
        if hasattr(cfg, k):
            setattr(cfg, k, v)
    return cfg
