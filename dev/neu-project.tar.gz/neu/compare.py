"""
Parse training logs and generate the ablation table from NEU-PROTOTYPE-PLAN.md §4.2.

Usage:
    python -m neu.compare                          # auto-discover logs in ~/logs/
    python -m neu.compare --log_dir /path/to/logs  # custom log directory
    python -m neu.compare --csv results.csv        # also write CSV
"""

import argparse
import re
import os
import sys
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class RunStats:
    model: str = ""
    params: int = 0
    scale: str = ""
    gpus: int = 1
    steps_completed: int = 0
    max_steps: int = 0

    # Training metrics (final values)
    final_train_loss: float = float("nan")
    final_ce_loss: float = float("nan")
    final_lr: float = float("nan")
    tokens_per_sec: float = float("nan")
    step_time_ms: float = float("nan")

    # Eval metrics (final values)
    final_val_loss: float = float("nan")
    final_ppl: float = float("nan")

    # Best eval
    best_val_loss: float = float("inf")
    best_ppl: float = float("inf")

    # Loss curve: list of (step, val_loss, ppl)
    eval_history: list = field(default_factory=list)
    # Training loss curve: list of (step, loss)
    train_history: list = field(default_factory=list)

    @property
    def finished(self) -> bool:
        return self.max_steps > 0 and self.steps_completed >= self.max_steps


# --- log line patterns ---

RE_MODEL = re.compile(
    r"Model:\s+(\w+)\s+\|\s+Scale:\s+(\w+)\s+\|\s+Params:\s+([\d,]+)"
)
RE_GPUS = re.compile(r"GPUs:\s+(\d+)")
RE_STEP = re.compile(
    r"step\s+(\d+)\s+\|\s+loss\s+([\d.]+)\s+\|\s+ce\s+([\d.]+)\s+\|"
    r"\s+lr\s+([\d.e+-]+)\s+\|\s+([\d,.]+)\s+tok/s\s+\|\s+(\d+)ms"
)
RE_EVAL = re.compile(
    r"eval\s+\|\s+val_loss\s+([\d.]+)\s+\|\s+ppl\s+([\d.]+)"
)


def parse_log(path: str) -> Optional[RunStats]:
    stats = RunStats()
    last_step = 0

    try:
        with open(path) as f:
            lines = f.readlines()
    except Exception as e:
        print(f"  Warning: cannot read {path}: {e}", file=sys.stderr)
        return None

    for line in lines:
        m = RE_MODEL.search(line)
        if m:
            stats.model = m.group(1)
            stats.scale = m.group(2)
            stats.params = int(m.group(3).replace(",", ""))
            continue

        m = RE_GPUS.search(line)
        if m:
            stats.gpus = int(m.group(1))
            continue

        m = RE_STEP.search(line)
        if m:
            step = int(m.group(1))
            loss = float(m.group(2))
            ce = float(m.group(3))
            lr = float(m.group(4))
            tps = float(m.group(5).replace(",", ""))
            ms = float(m.group(6))

            last_step = step
            stats.final_train_loss = loss
            stats.final_ce_loss = ce
            stats.final_lr = lr
            stats.tokens_per_sec = tps
            stats.step_time_ms = ms
            stats.train_history.append((step, loss))
            continue

        m = RE_EVAL.search(line)
        if m:
            vl = float(m.group(1))
            ppl = float(m.group(2))
            stats.eval_history.append((last_step, vl, ppl))
            stats.final_val_loss = vl
            stats.final_ppl = ppl
            if vl < stats.best_val_loss:
                stats.best_val_loss = vl
                stats.best_ppl = ppl

    stats.steps_completed = last_step
    if not stats.model:
        return None
    return stats


def discover_logs(log_dir: str) -> list[str]:
    paths = []
    for name in sorted(os.listdir(log_dir)):
        if name.endswith(".log") and name != "run_all.log":
            paths.append(os.path.join(log_dir, name))
    return paths


def fmt(val, decimals=4):
    if val != val:  # nan check
        return "—"
    if isinstance(val, float):
        if val == float("inf"):
            return "—"
        return f"{val:.{decimals}f}"
    return str(val)


def fmt_int(val):
    if val == 0:
        return "—"
    if val >= 1_000_000:
        return f"{val / 1_000_000:.1f}M"
    if val >= 1_000:
        return f"{val / 1_000:.0f}K"
    return str(val)


def fmt_tps(val):
    if val != val:
        return "—"
    return f"{val:,.0f}"


def print_ablation_table(runs: list[RunStats]):
    """Print the Phase 4.2 ablation table."""
    print()
    print("=" * 90)
    print("  Neu Ablation Table — Phase 0 Baselines")
    print("=" * 90)

    header = f"{'Config':<20s} {'Params':>8s} {'Steps':>8s} {'Val Loss':>10s} {'PPL':>8s} {'Tok/s':>10s} {'ms/step':>8s}"
    print(header)
    print("-" * 90)

    preferred_order = ["transformer", "mamba2", "fixed_hybrid", "neu"]
    ordered = sorted(runs, key=lambda r: (
        preferred_order.index(r.model) if r.model in preferred_order else 99
    ))

    for r in ordered:
        status = "" if r.finished else " (running)" if r.steps_completed > 0 else " (queued)"
        line = (
            f"{r.model + status:<20s} "
            f"{fmt_int(r.params):>8s} "
            f"{r.steps_completed:>8d} "
            f"{fmt(r.final_val_loss):>10s} "
            f"{fmt(r.final_ppl, 2):>8s} "
            f"{fmt_tps(r.tokens_per_sec):>10s} "
            f"{fmt(r.step_time_ms, 0):>8s}"
        )
        print(line)

    print("-" * 90)
    print()

    # Loss curve comparison at common eval points
    all_eval_steps = set()
    for r in runs:
        for step, _, _ in r.eval_history:
            all_eval_steps.add(step)
    common_steps = sorted(all_eval_steps)

    if len(common_steps) > 1 and len(runs) > 1:
        print("  Val Loss @ Eval Steps (first 10)")
        print("-" * 90)
        step_header = f"{'Step':>8s}"
        for r in ordered:
            step_header += f"  {r.model:>14s}"
        print(step_header)
        print("-" * 90)

        eval_by_model = {}
        for r in ordered:
            d = {}
            for step, vl, ppl in r.eval_history:
                d[step] = vl
            eval_by_model[r.model] = d

        for i, step in enumerate(common_steps[:10]):
            row = f"{step:>8d}"
            for r in ordered:
                vl = eval_by_model[r.model].get(step)
                row += f"  {fmt(vl):>14s}" if vl is not None else f"  {'—':>14s}"
            print(row)
        print("-" * 90)
        print()


def write_csv(runs: list[RunStats], path: str):
    import csv
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow([
            "model", "params", "scale", "gpus", "steps", "finished",
            "final_val_loss", "final_ppl", "best_val_loss", "best_ppl",
            "final_train_loss", "tokens_per_sec", "step_time_ms",
        ])
        for r in runs:
            w.writerow([
                r.model, r.params, r.scale, r.gpus, r.steps_completed, r.finished,
                r.final_val_loss, r.final_ppl, r.best_val_loss, r.best_ppl,
                r.final_train_loss, r.tokens_per_sec, r.step_time_ms,
            ])
    print(f"CSV written to {path}")


def main():
    parser = argparse.ArgumentParser(description="Compare Neu training runs")
    parser.add_argument("--log_dir", type=str, default=os.path.expanduser("~/logs"),
                        help="Directory containing training logs")
    parser.add_argument("--csv", type=str, default=None,
                        help="Write results to CSV file")
    parser.add_argument("--max_steps", type=int, default=20_000,
                        help="Expected max_steps for determining completion status")
    args = parser.parse_args()

    log_files = discover_logs(args.log_dir)
    if not log_files:
        print(f"No log files found in {args.log_dir}")
        sys.exit(1)

    print(f"Found {len(log_files)} log file(s) in {args.log_dir}")
    runs = []
    for path in log_files:
        r = parse_log(path)
        if r:
            r.max_steps = args.max_steps
            runs.append(r)
            print(f"  {os.path.basename(path)}: {r.model} — {r.steps_completed} steps")

    if not runs:
        print("No valid runs found.")
        sys.exit(1)

    print_ablation_table(runs)

    if args.csv:
        write_csv(runs, args.csv)


if __name__ == "__main__":
    main()
