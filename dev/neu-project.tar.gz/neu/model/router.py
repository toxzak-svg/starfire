import torch
import torch.nn as nn
import torch.nn.functional as F


class Router(nn.Module):
    """Per-token routing over {SSM, attention, cheap} paths."""

    def __init__(self, d_model: int, n_paths: int = 3, temperature: float = 1.0):
        super().__init__()
        self.n_paths = n_paths
        self.temperature = temperature
        self.proj = nn.Linear(d_model, n_paths, bias=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        logits = self.proj(x) / self.temperature  # (B, T, P)
        return F.softmax(logits, dim=-1)


class StateAwareRouter(nn.Module):
    """Per-token routing conditioned on persistent state."""

    def __init__(
        self,
        d_model: int,
        d_state: int,
        n_paths: int = 3,
        temperature: float = 1.0,
    ):
        super().__init__()
        self.n_paths = n_paths
        self.temperature = temperature
        self.state_proj = nn.Linear(d_state, d_model, bias=False)
        self.gate_proj = nn.Linear(d_model, n_paths, bias=True)

    def forward(self, x: torch.Tensor, state: torch.Tensor) -> torch.Tensor:
        # Fuse state into token features via addition (cheaper than concat)
        s = self.state_proj(state).unsqueeze(1)  # (B, 1, D)
        h = x + s
        logits = self.gate_proj(h) / self.temperature  # (B, T, P)
        return F.softmax(logits, dim=-1)


def load_balance_loss(gates: torch.Tensor, alpha: float = 0.01) -> torch.Tensor:
    """
    Encourages uniform path utilization across tokens.
    gates: (B, T, P) — soft gate values after softmax.
    Returns scalar loss.
    """
    frac = gates.mean(dim=(0, 1))  # (P,)
    target = torch.ones_like(frac) / frac.shape[0]
    return alpha * F.mse_loss(frac, target)
