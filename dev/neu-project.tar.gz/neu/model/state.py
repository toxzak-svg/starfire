import torch
import torch.nn as nn


class PersistentState(nn.Module):
    """
    Small per-batch state vector that persists across block steps.
    Captures slow-moving context (topic, difficulty, domain) to
    inform routing decisions.
    """

    def __init__(self, d_model: int, d_state: int = 64):
        super().__init__()
        self.d_state = d_state
        self.update_gate = nn.Linear(d_model + d_state, d_state)
        self.update_candidate = nn.Linear(d_model + d_state, d_state)

    def init_state(self, batch_size: int, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
        return torch.zeros(batch_size, self.d_state, device=device, dtype=dtype)

    def step(self, x: torch.Tensor, state: torch.Tensor) -> torch.Tensor:
        """
        Update state from token summary. Minimal GRU-style gating
        without nn.GRUCell to keep it fused and torch.compile-friendly.
        """
        summary = x.mean(dim=1)  # (B, D)
        combined = torch.cat([summary, state], dim=-1)  # (B, D + d_state)
        z = torch.sigmoid(self.update_gate(combined))
        candidate = torch.tanh(self.update_candidate(combined))
        return (1 - z) * state + z * candidate
