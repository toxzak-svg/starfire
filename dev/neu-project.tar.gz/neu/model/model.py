import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint as grad_checkpoint
from typing import Optional, Dict, Any

from .block import NeuBlock, RMSNorm
from .state import PersistentState
from .router import load_balance_loss


class NeuModel(nn.Module):
    """
    Full Neu language model: embedding -> stack of NeuBlocks -> LM head.
    Persistent state is updated once per block and fed to the next block's router.
    """

    def __init__(
        self,
        d_model: int = 768,
        n_layers: int = 12,
        n_heads: int = 12,
        vocab_size: int = 32000,
        max_seq_len: int = 2048,
        d_ssm_state: int = 64,
        ssm_expand: int = 2,
        ssm_conv_size: int = 4,
        attn_window_size: int = 512,
        cheap_ratio: int = 4,
        n_paths: int = 3,
        gate_temperature: float = 1.0,
        d_persistent_state: int = 64,
        use_persistent_state: bool = True,
        load_balance_weight: float = 0.01,
        dropout: float = 0.0,
        norm_eps: float = 1e-6,
    ):
        super().__init__()
        self.d_model = d_model
        self.n_layers = n_layers
        self.use_persistent_state = use_persistent_state
        self.load_balance_weight = load_balance_weight
        self._gradient_checkpointing = False

        self.tok_emb = nn.Embedding(vocab_size, d_model)
        self.drop = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

        self.blocks = nn.ModuleList([
            NeuBlock(
                d_model=d_model,
                n_heads=n_heads,
                d_ssm_state=d_ssm_state,
                ssm_expand=ssm_expand,
                ssm_conv_size=ssm_conv_size,
                attn_window_size=attn_window_size,
                cheap_ratio=cheap_ratio,
                n_paths=n_paths,
                gate_temperature=gate_temperature,
                d_persistent_state=d_persistent_state,
                use_persistent_state=use_persistent_state,
                dropout=dropout,
                norm_eps=norm_eps,
            )
            for _ in range(n_layers)
        ])

        self.norm_f = RMSNorm(d_model, eps=norm_eps)
        self.lm_head = nn.Linear(d_model, vocab_size, bias=False)

        # Weight tying
        self.lm_head.weight = self.tok_emb.weight

        if use_persistent_state:
            self.persistent_state = PersistentState(d_model, d_persistent_state)

        self.apply(self._init_weights)

    def _init_weights(self, module: nn.Module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(
        self,
        input_ids: torch.Tensor,
        targets: Optional[torch.Tensor] = None,
        persistent_state: Optional[torch.Tensor] = None,
    ) -> Dict[str, Any]:
        B, T = input_ids.shape
        x = self.drop(self.tok_emb(input_ids))

        if self.use_persistent_state:
            if persistent_state is None:
                persistent_state = self.persistent_state.init_state(
                    B, x.device, x.dtype
                )

        all_gates = []
        for block in self.blocks:
            if self._gradient_checkpointing and self.training:
                x, gates = grad_checkpoint(
                    block, x, persistent_state, use_reentrant=False
                )
            else:
                x, gates = block(x, persistent_state)
            all_gates.append(gates)

            if self.use_persistent_state:
                persistent_state = self.persistent_state.step(x, persistent_state)

        x = self.norm_f(x)
        logits = self.lm_head(x)

        result = {
            "logits": logits,
            "persistent_state": persistent_state,
            "gates": all_gates,
        }

        if targets is not None:
            loss = nn.functional.cross_entropy(
                logits.view(-1, logits.size(-1)),
                targets.view(-1),
                ignore_index=-1,
            )
            # Aggregate load balance loss across all layers
            lb_loss = sum(load_balance_loss(g, self.load_balance_weight) for g in all_gates)
            result["loss"] = loss + lb_loss
            result["ce_loss"] = loss
            result["lb_loss"] = lb_loss

        return result

    @classmethod
    def from_config(cls, config) -> "NeuModel":
        return cls(
            d_model=config.d_model,
            n_layers=config.n_layers,
            n_heads=config.n_heads,
            vocab_size=config.vocab_size,
            max_seq_len=config.max_seq_len,
            d_ssm_state=config.d_ssm_state,
            ssm_expand=config.ssm_expand,
            ssm_conv_size=config.ssm_conv_size,
            attn_window_size=config.attn_window_size,
            cheap_ratio=config.cheap_ratio,
            n_paths=config.n_paths,
            gate_temperature=config.gate_temperature,
            d_persistent_state=config.d_persistent_state,
            use_persistent_state=config.use_persistent_state,
            load_balance_weight=config.load_balance_weight,
            dropout=config.dropout,
            norm_eps=config.norm_eps,
        )

    def param_count(self) -> int:
        return sum(p.numel() for p in self.parameters())

    def set_temperature(self, temperature: float):
        """Update gate temperature across all blocks (for annealing)."""
        for block in self.blocks:
            block.router.temperature = temperature

    def enable_gradient_checkpointing(self, enable: bool = True):
        self._gradient_checkpointing = enable
