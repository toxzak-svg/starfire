import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple

from .router import Router, StateAwareRouter, load_balance_loss
from .cheap_path import CheapPath
from .state import PersistentState


class RMSNorm(nn.Module):
    def __init__(self, d_model: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(d_model))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.rms_norm(x, self.weight.shape, self.weight, self.eps)


class SSMLayer(nn.Module):
    """
    Wrapper around mamba_ssm.Mamba2. Falls back to a simple MLP
    if mamba_ssm is not installed, or identity on CPU when Mamba2
    is available (Mamba2 requires CUDA).
    """

    def __init__(self, d_model: int, d_state: int = 64, expand: int = 2, conv_size: int = 4):
        super().__init__()
        self.d_model = d_model
        self._has_mamba = False
        try:
            from mamba_ssm import Mamba2
            self.ssm = Mamba2(
                d_model=d_model,
                d_state=d_state,
                d_conv=conv_size,
                expand=expand,
                use_mem_eff_path=False,
            )
            self._has_mamba = True
        except ImportError:
            self.ssm = nn.Sequential(
                nn.Linear(d_model, d_model * expand),
                nn.SiLU(),
                nn.Linear(d_model * expand, d_model),
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self._has_mamba:
            if x.is_cuda:
                return self.ssm(x)
            return x
        return self.ssm(x)


_HAS_FLASH_ATTN = False
try:
    from flash_attn import flash_attn_func
    _HAS_FLASH_ATTN = True
except ImportError:
    pass


class LocalAttention(nn.Module):
    """
    Sliding-window self-attention. Uses FlashAttention if available,
    otherwise falls back to SDPA with a windowed mask.
    """

    def __init__(self, d_model: int, n_heads: int, window_size: int = 512, dropout: float = 0.0):
        super().__init__()
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.window_size = window_size
        self.qkv = nn.Linear(d_model, 3 * d_model, bias=False)
        self.out_proj = nn.Linear(d_model, d_model, bias=False)
        self.dropout = dropout

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, D = x.shape
        qkv = self.qkv(x).reshape(B, T, 3, self.n_heads, self.head_dim)
        q, k, v = qkv.unbind(dim=2)
        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)

        drop_p = self.dropout if self.training else 0.0

        if _HAS_FLASH_ATTN and x.is_cuda:
            q_fa = q.transpose(1, 2)
            k_fa = k.transpose(1, 2)
            v_fa = v.transpose(1, 2)
            out = flash_attn_func(
                q_fa, k_fa, v_fa,
                dropout_p=drop_p,
                causal=True,
                window_size=(self.window_size, 0),
            ).reshape(B, T, D)
        else:
            causal_mask = torch.ones(T, T, dtype=torch.bool, device=x.device).triu(1)
            window_mask = torch.ones(T, T, dtype=torch.bool, device=x.device).tril(-self.window_size)
            mask = ~(causal_mask | window_mask)
            out = F.scaled_dot_product_attention(
                q, k, v, attn_mask=mask, dropout_p=drop_p,
            ).transpose(1, 2).reshape(B, T, D)

        return self.out_proj(out)


class NeuBlock(nn.Module):
    """
    Core Neu block: routes each token through SSM, attention, or cheap path
    using learned soft gates. All three paths run during training (soft mix).
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        d_ssm_state: int = 64,
        ssm_expand: int = 2,
        ssm_conv_size: int = 4,
        attn_window_size: int = 512,
        cheap_ratio: int = 4,
        n_paths: int = 3,
        gate_temperature: float = 1.0,
        d_persistent_state: int = 64,
        use_persistent_state: bool = True,
        dropout: float = 0.0,
        norm_eps: float = 1e-6,
    ):
        super().__init__()
        self.use_persistent_state = use_persistent_state

        self.norm = RMSNorm(d_model, eps=norm_eps)
        self.ssm = SSMLayer(d_model, d_state=d_ssm_state, expand=ssm_expand, conv_size=ssm_conv_size)
        self.attn = LocalAttention(d_model, n_heads, window_size=attn_window_size, dropout=dropout)
        self.cheap = CheapPath(d_model, ratio=cheap_ratio)

        if use_persistent_state:
            self.router = StateAwareRouter(d_model, d_persistent_state, n_paths, gate_temperature)
        else:
            self.router = Router(d_model, n_paths, gate_temperature)

    def forward(
        self,
        x: torch.Tensor,
        persistent_state: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Returns (output, gate_values).
        Gate values are returned for logging and load-balance loss.
        """
        h = self.norm(x)

        if self.use_persistent_state and persistent_state is not None:
            gates = self.router(h, persistent_state)  # (B, T, P)
        else:
            gates = self.router(h)  # (B, T, P)

        y_ssm = self.ssm(h)
        y_attn = self.attn(h)
        y_cheap = self.cheap(h)

        y = (
            gates[..., 0:1] * y_ssm
            + gates[..., 1:2] * y_attn
            + gates[..., 2:3] * y_cheap
        )

        return x + y, gates
