import torch
import torch.nn as nn
import torch.nn.functional as F


class CheapPath(nn.Module):
    """
    Lightweight MLP for tokens that don't need heavy SSM or attention.
    Hidden dim is d_model // ratio, so this is significantly cheaper
    than either SSM or attention layers.
    """

    def __init__(self, d_model: int, ratio: int = 4):
        super().__init__()
        d_hidden = d_model // ratio
        self.w1 = nn.Linear(d_model, d_hidden)
        self.w2 = nn.Linear(d_hidden, d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.w2(F.gelu(self.w1(x)))
