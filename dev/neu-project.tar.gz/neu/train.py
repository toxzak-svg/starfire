"""
Unified training loop for Neu and all baselines.
Usage:
    # Single GPU
    python -m neu.train --model neu --scale 150m

    # Multi-GPU (2x RTX 5000)
    torchrun --nproc_per_node=2 -m neu.train --model neu --scale 150m

    # Baselines
    torchrun --nproc_per_node=2 -m neu.train --model mamba2 --scale 150m
    torchrun --nproc_per_node=2 -m neu.train --model transformer --scale 150m
    torchrun --nproc_per_node=2 -m neu.train --model fixed_hybrid --scale 150m
"""

import argparse
import math
import os
import signal
import sys
import time
import traceback
from contextlib import nullcontext
from datetime import timedelta
from typing import Optional

import torch
import torch.nn.functional as F
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader

from neu.config import get_config, TrainConfig, ModelConfig
from neu.data import get_dataloader
from neu.model.model import NeuModel
from neu.baselines.mamba2 import Mamba2Model
from neu.baselines.transformer import TransformerModel
from neu.baselines.fixed_hybrid import FixedHybridModel


MODEL_CLASSES = {
    "neu": NeuModel,
    "mamba2": Mamba2Model,
    "transformer": TransformerModel,
    "fixed_hybrid": FixedHybridModel,
}


def is_distributed():
    return dist.is_initialized()


def rank():
    return dist.get_rank() if is_distributed() else 0


def world_size():
    return dist.get_world_size() if is_distributed() else 1


def is_main():
    return rank() == 0


def setup_distributed():
    if "RANK" in os.environ:
        dist.init_process_group("nccl", timeout=timedelta(minutes=30))
        torch.cuda.set_device(int(os.environ["LOCAL_RANK"]))
        return True
    return False


def cleanup_distributed():
    if is_distributed():
        dist.destroy_process_group()


def unwrap_model(model):
    """Get the raw model from DDP/compiled wrappers."""
    m = model
    if hasattr(m, "module"):
        m = m.module
    if hasattr(m, "_orig_mod"):
        m = m._orig_mod
    return m


def get_lr(step: int, cfg: TrainConfig) -> float:
    """Cosine schedule with linear warmup."""
    if step < cfg.warmup_steps:
        return cfg.lr * step / cfg.warmup_steps
    if step >= cfg.max_steps:
        return cfg.min_lr
    progress = (step - cfg.warmup_steps) / (cfg.max_steps - cfg.warmup_steps)
    return cfg.min_lr + 0.5 * (cfg.lr - cfg.min_lr) * (1 + math.cos(math.pi * progress))


def get_temperature(step: int, cfg: TrainConfig) -> float:
    """Linear temperature annealing for gate sharpening."""
    if not cfg.anneal_temp or step < cfg.anneal_start_step:
        return 1.0
    if step >= cfg.anneal_end_step:
        return cfg.anneal_final_temp
    progress = (step - cfg.anneal_start_step) / (cfg.anneal_end_step - cfg.anneal_start_step)
    return 1.0 + progress * (cfg.anneal_final_temp - 1.0)


def log_gate_stats(gates_list, step, logger):
    """Log per-layer gate distribution stats."""
    for i, gates in enumerate(gates_list):
        mean_gates = gates.detach().float().mean(dim=(0, 1))
        stats = {
            f"gates/layer_{i}_ssm": mean_gates[0].item(),
            f"gates/layer_{i}_attn": mean_gates[1].item(),
            f"gates/layer_{i}_cheap": mean_gates[2].item(),
        }
        if logger is not None:
            logger.log(stats, step=step)


@torch.no_grad()
def evaluate(model, eval_loader, device, ctx, max_steps: int = 50):
    model.eval()
    total_loss = 0.0
    n = 0
    for i, batch in enumerate(eval_loader):
        if i >= max_steps:
            break
        input_ids = batch["input_ids"].to(device)
        targets = batch["targets"].to(device)
        with ctx:
            raw = unwrap_model(model)
            out = raw(input_ids, targets=targets)
        total_loss += out["ce_loss"].item() if "ce_loss" in out else out["loss"].item()
        n += 1
    model.train()
    return total_loss / max(n, 1)


def train(model_name: str, scale: str, train_cfg: TrainConfig, model_overrides: dict):
    ddp = setup_distributed()
    local_rank = int(os.environ.get("LOCAL_RANK", 0))
    device = f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu"

    dtype = {"float32": torch.float32, "bfloat16": torch.bfloat16, "float16": torch.float16}[train_cfg.dtype]
    ctx = torch.amp.autocast(device_type="cuda", dtype=dtype) if "cuda" in device else nullcontext()

    model_cfg = get_config(scale, **model_overrides)
    model_cls = MODEL_CLASSES[model_name]
    model = model_cls.from_config(model_cfg).to(device)

    if train_cfg.gradient_checkpointing and hasattr(model, "enable_gradient_checkpointing"):
        model.enable_gradient_checkpointing(True)

    if is_main():
        gc_status = "on" if train_cfg.gradient_checkpointing else "off"
        print(f"Model: {model_name} | Scale: {scale} | Params: {model.param_count():,}")
        print(f"GPUs: {world_size()} | DDP: {ddp} | Device: {device} | GradCkpt: {gc_status}")

    # Warmup: trigger Triton kernel compilation before DDP to avoid
    # NCCL timeout from asymmetric compile times across ranks.
    if "cuda" in device:
        if is_main():
            print("Warmup: compiling kernels...")
        dummy_ids = torch.zeros(2, 64, dtype=torch.long, device=device)
        dummy_tgt = torch.zeros(2, 64, dtype=torch.long, device=device)
        with torch.amp.autocast(device_type="cuda", dtype=dtype):
            _out = model(dummy_ids, targets=dummy_tgt)
            _out["loss"].backward()
        model.zero_grad(set_to_none=True)
        torch.cuda.synchronize()
        if ddp:
            dist.barrier()
        if is_main():
            print("Warmup done")

    if train_cfg.compile and "cuda" in device:
        model = torch.compile(model)

    if ddp:
        model = DDP(model, device_ids=[local_rank])

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=train_cfg.lr,
        betas=train_cfg.betas,
        weight_decay=train_cfg.weight_decay,
    )

    train_loader = get_dataloader(train_cfg, split="train", rank=rank(), world_size=world_size())
    eval_loader = get_dataloader(train_cfg, split="validation") if is_main() else None

    logger = None
    if is_main():
        try:
            import wandb
            if getattr(train_cfg, "wandb_offline", False):
                import os
                os.environ["WANDB_MODE"] = "offline"
            run_name = train_cfg.wandb_run or f"{model_name}_{scale}"
            wandb.init(project=train_cfg.wandb_project, name=run_name, config={
                "model": model_name, "scale": scale, "gpus": world_size(),
                "model_cfg": model_cfg.__dict__, "train_cfg": train_cfg.__dict__,
            })
            logger = wandb
        except ImportError:
            print("wandb not installed, logging to stdout only")

    scaler = torch.amp.GradScaler("cuda", enabled=(dtype == torch.float16))

    train_iter = iter(train_loader)
    model.train()

    for step in range(1, train_cfg.max_steps + 1):
        t0 = time.time()

        lr = get_lr(step, train_cfg)
        for pg in optimizer.param_groups:
            pg["lr"] = lr

        if model_name == "neu":
            temp = get_temperature(step, train_cfg)
            raw = unwrap_model(model)
            if hasattr(raw, "set_temperature"):
                raw.set_temperature(temp)

        optimizer.zero_grad(set_to_none=True)
        accum_loss = 0.0
        accum_ce = 0.0

        for micro in range(train_cfg.gradient_accumulation_steps):
            try:
                batch = next(train_iter)
            except StopIteration:
                train_iter = iter(train_loader)
                batch = next(train_iter)

            input_ids = batch["input_ids"].to(device)
            targets = batch["targets"].to(device)

            sync_ctx = model.no_sync() if (ddp and micro < train_cfg.gradient_accumulation_steps - 1) else nullcontext()

            with sync_ctx:
                with ctx:
                    out = model(input_ids, targets=targets)
                    loss = out["loss"] / train_cfg.gradient_accumulation_steps

                scaler.scale(loss).backward()

            accum_loss += out["loss"].item() / train_cfg.gradient_accumulation_steps
            ce = out.get("ce_loss", out["loss"])
            accum_ce += ce.item() / train_cfg.gradient_accumulation_steps

        if train_cfg.grad_clip > 0:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), train_cfg.grad_clip)

        scaler.step(optimizer)
        scaler.update()

        dt = time.time() - t0

        if is_main() and step % train_cfg.log_interval == 0:
            tokens_per_sec = (
                train_cfg.batch_size * train_cfg.seq_len
                * train_cfg.gradient_accumulation_steps * world_size() / dt
            )
            msg = (
                f"step {step:>6d} | loss {accum_loss:.4f} | ce {accum_ce:.4f} | "
                f"lr {lr:.2e} | {tokens_per_sec:,.0f} tok/s | {dt*1000:.0f}ms"
            )
            print(msg)

            if logger is not None:
                log_data = {
                    "train/loss": accum_loss,
                    "train/ce_loss": accum_ce,
                    "train/lr": lr,
                    "train/tokens_per_sec": tokens_per_sec,
                    "train/step_time_ms": dt * 1000,
                }
                if model_name == "neu" and "lb_loss" in out:
                    log_data["train/lb_loss"] = out["lb_loss"].item()
                logger.log(log_data, step=step)

            if model_name == "neu" and "gates" in out:
                log_gate_stats(out["gates"], step, logger)

        del out, loss

        if step % train_cfg.eval_interval == 0:
            if is_main():
                val_loss = evaluate(model, eval_loader, device, ctx, train_cfg.eval_steps)
                ppl = math.exp(min(val_loss, 20))
                print(f"  eval | val_loss {val_loss:.4f} | ppl {ppl:.2f}")
                if logger is not None:
                    logger.log({"eval/loss": val_loss, "eval/ppl": ppl}, step=step)
                torch.cuda.empty_cache()
            if ddp:
                dist.barrier()

        if step % train_cfg.save_interval == 0:
            if is_main():
                os.makedirs(train_cfg.save_dir, exist_ok=True)
                ckpt_path = os.path.join(train_cfg.save_dir, f"{model_name}_{scale}_step{step}.pt")
                raw = unwrap_model(model)
                torch.save({
                    "step": step,
                    "model": raw.state_dict(),
                    "optimizer": optimizer.state_dict(),
                    "model_cfg": model_cfg.__dict__,
                    "train_cfg": train_cfg.__dict__,
                }, ckpt_path)
                print(f"  saved checkpoint: {ckpt_path}")
            if ddp:
                dist.barrier()

    if logger is not None:
        logger.finish()
    cleanup_distributed()


def main():
    parser = argparse.ArgumentParser(description="Train Neu or baseline models")
    parser.add_argument("--model", type=str, default="neu", choices=MODEL_CLASSES.keys())
    parser.add_argument("--scale", type=str, default="150m", choices=["150m", "350m", "1b"])
    parser.add_argument("--batch_size", type=int, default=None)
    parser.add_argument("--max_steps", type=int, default=None)
    parser.add_argument("--lr", type=float, default=None)
    parser.add_argument("--seq_len", type=int, default=None)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=None)
    parser.add_argument("--no_compile", action="store_true")
    parser.add_argument("--gradient_checkpointing", action="store_true",
                        help="Trade compute for memory: recompute activations during backward")
    parser.add_argument("--no_persistent_state", action="store_true")
    parser.add_argument("--anneal_temp", action="store_true")
    parser.add_argument("--wandb_run", type=str, default=None)
    parser.add_argument("--save_dir", type=str, default="checkpoints")
    parser.add_argument("--dtype", type=str, default="bfloat16")
    args = parser.parse_args()

    train_cfg = TrainConfig()
    if args.batch_size is not None:
        train_cfg.batch_size = args.batch_size
    if args.max_steps is not None:
        train_cfg.max_steps = args.max_steps
    if args.lr is not None:
        train_cfg.lr = args.lr
    if args.seq_len is not None:
        train_cfg.seq_len = args.seq_len
    if args.gradient_accumulation_steps is not None:
        train_cfg.gradient_accumulation_steps = args.gradient_accumulation_steps
    train_cfg.compile = not args.no_compile
    train_cfg.gradient_checkpointing = args.gradient_checkpointing
    train_cfg.anneal_temp = args.anneal_temp
    train_cfg.save_dir = args.save_dir
    train_cfg.dtype = args.dtype
    if args.wandb_run:
        train_cfg.wandb_run = args.wandb_run

    model_overrides = {}
    if args.no_persistent_state:
        model_overrides["use_persistent_state"] = False

    try:
        train(args.model, args.scale, train_cfg, model_overrides)
    except Exception as e:
        crash_text = traceback.format_exc()
        print(f"\n{'='*60}", file=sys.stderr)
        print(f"CRASH: {type(e).__name__}: {e}", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)
        print(crash_text, file=sys.stderr)
        try:
            import wandb
            if wandb.run is not None:
                wandb.run.summary["crash_error"] = f"{type(e).__name__}: {e}"
                wandb.run.summary["crash_traceback"] = crash_text
                wandb.finish(exit_code=1)
        except Exception:
            pass
        raise


def _crash_signal_handler(signum, frame):
    """Log signal-based kills (SIGTERM from torchrun) to wandb."""
    sig_name = signal.Signals(signum).name
    print(f"\nReceived {sig_name}, logging to wandb...", file=sys.stderr)
    try:
        import wandb
        if wandb.run is not None:
            wandb.run.summary["crash_error"] = f"Killed by signal: {sig_name}"
            wandb.finish(exit_code=128 + signum)
    except Exception:
        pass
    sys.exit(128 + signum)


signal.signal(signal.SIGTERM, _crash_signal_handler)


if __name__ == "__main__":
    main()
