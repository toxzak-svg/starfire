"""
Smoke test: forward + backward pass for all 4 models on CPU with a tiny config.
Run from /home/zach:  python -m neu.smoke_test
"""

import sys
import torch
from neu.config import ModelConfig
from neu.model.model import NeuModel
from neu.baselines.mamba2 import Mamba2Model
from neu.baselines.transformer import TransformerModel
from neu.baselines.fixed_hybrid import FixedHybridModel

TINY = ModelConfig(
    d_model=64,
    n_layers=2,
    n_heads=4,
    vocab_size=256,
    max_seq_len=64,
    d_ssm_state=16,
    ssm_expand=2,
    ssm_conv_size=4,
    attn_window_size=32,
    cheap_ratio=4,
    n_paths=3,
    gate_temperature=1.0,
    d_persistent_state=16,
    use_persistent_state=True,
    dropout=0.0,
)

B, T = 2, 32
MODELS = {
    "neu": NeuModel,
    "mamba2": Mamba2Model,
    "transformer": TransformerModel,
    "fixed_hybrid": FixedHybridModel,
}


def run_one(name, cls, device="cpu"):
    tag = f"{name}({device})"
    print(f"  {tag:25s} ... ", end="", flush=True)
    model = cls.from_config(TINY).to(device)
    params = sum(p.numel() for p in model.parameters())

    ids = torch.randint(0, TINY.vocab_size, (B, T), device=device)
    targets = torch.randint(0, TINY.vocab_size, (B, T), device=device)
    out = model(ids, targets=targets)

    assert "logits" in out, "missing logits"
    assert "loss" in out, "missing loss"
    assert out["logits"].shape == (B, T, TINY.vocab_size), f"bad logits shape: {out['logits'].shape}"

    out["loss"].backward()

    grad_ok = any(p.grad is not None and p.grad.abs().sum() > 0 for p in model.parameters())
    assert grad_ok, "no gradients flowed"

    if name == "neu":
        assert "gates" in out, "neu model should return gates"
        assert "ce_loss" in out, "neu model should return ce_loss"
        assert "lb_loss" in out, "neu model should return lb_loss"
        for g in out["gates"]:
            sums = g.sum(dim=-1)
            assert torch.allclose(sums, torch.ones_like(sums), atol=1e-5), "gates don't sum to 1"

    print(f"ok  ({params:,} params, loss={out['loss'].item():.3f})")


def test_temperature_annealing():
    print(f"  {'temp_anneal':25s} ... ", end="", flush=True)
    model = NeuModel.from_config(TINY)
    model.set_temperature(0.5)
    for block in model.blocks:
        assert block.router.temperature == 0.5
    model.set_temperature(1.0)
    print("ok")


def test_persistent_state_step(device="cpu"):
    tag = f"state_step({device})"
    print(f"  {tag:25s} ... ", end="", flush=True)
    model = NeuModel.from_config(TINY).to(device)
    ids = torch.randint(0, TINY.vocab_size, (B, T), device=device)
    out1 = model(ids)
    s1 = out1["persistent_state"]
    out2 = model(ids, persistent_state=s1)
    s2 = out2["persistent_state"]
    assert not torch.allclose(s1, s2), "state should change between steps"
    print("ok")


def main():
    print("=== Neu smoke test ===\n")
    ok = True

    devices = ["cpu"]
    if torch.cuda.is_available():
        devices.append("cuda")

    for device in devices:
        for name, cls in MODELS.items():
            try:
                run_one(name, cls, device=device)
            except Exception as e:
                print(f"FAIL: {e}")
                ok = False

    try:
        test_temperature_annealing()
    except Exception as e:
        print(f"FAIL: {e}")
        ok = False

    for device in devices:
        try:
            test_persistent_state_step(device=device)
        except Exception as e:
            print(f"FAIL: {e}")
            ok = False

    print()
    if ok:
        print("All checks passed.")
    else:
        print("Some checks FAILED.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
