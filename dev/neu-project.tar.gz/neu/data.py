"""
Data loading for training. Streams from HuggingFace datasets,
tokenizes on the fly, and packs into fixed-length sequences.
"""

import torch
from torch.utils.data import IterableDataset, DataLoader
from typing import Iterator, Dict


class PackedTokenDataset(IterableDataset):
    """
    Streams text from a HuggingFace dataset, tokenizes, and packs tokens
    into fixed-length (seq_len + 1) chunks. The +1 is for the target shift.
    """

    VAL_SKIP = 10_000

    def __init__(self, dataset_name: str, tokenizer_name: str, seq_len: int,
                 split: str = "train", text_field: str = "text",
                 rank: int = 0, world_size: int = 1):
        self.dataset_name = dataset_name
        self.tokenizer_name = tokenizer_name
        self.seq_len = seq_len
        self.split = split
        self.text_field = text_field
        self.rank = rank
        self.world_size = world_size

    def _get_stream(self) -> Iterator[Dict[str, torch.Tensor]]:
        from datasets import load_dataset
        from transformers import AutoTokenizer

        tokenizer = AutoTokenizer.from_pretrained(self.tokenizer_name)
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token

        ds = load_dataset(self.dataset_name, split="train", streaming=True)
        if self.split == "validation":
            ds = ds.skip(self.VAL_SKIP)
        if self.split == "train":
            worker_info = torch.utils.data.get_worker_info()
            if worker_info is not None:
                nw = worker_info.num_workers
                wid = worker_info.id
                total_shards = self.world_size * nw
                shard_index = self.rank * nw + wid
                ds = ds.shard(num_shards=total_shards, index=shard_index)
            elif self.world_size > 1:
                ds = ds.shard(num_shards=self.world_size, index=self.rank)
        chunk_size = self.seq_len + 1
        buffer = []

        for example in ds:
            text = example.get(self.text_field, "")
            if not text:
                continue
            tokens = tokenizer.encode(text, add_special_tokens=False)
            buffer.extend(tokens)

            while len(buffer) >= chunk_size:
                chunk = buffer[:chunk_size]
                buffer = buffer[chunk_size:]
                t = torch.tensor(chunk, dtype=torch.long)
                yield {
                    "input_ids": t[:-1],
                    "targets": t[1:],
                }

    def __iter__(self):
        return self._get_stream()


def get_dataloader(train_cfg, split: str = "train", rank: int = 0, world_size: int = 1) -> DataLoader:
    ds = PackedTokenDataset(
        dataset_name=train_cfg.dataset,
        tokenizer_name=train_cfg.tokenizer,
        seq_len=train_cfg.seq_len,
        split=split,
        rank=rank,
        world_size=world_size,
    )
    num_workers = getattr(train_cfg, "num_workers", 0)
    return DataLoader(
        ds,
        batch_size=train_cfg.batch_size,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=True,
    )
