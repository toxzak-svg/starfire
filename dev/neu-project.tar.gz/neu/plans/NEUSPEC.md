# NeuralOS Scheduler and OS State: Canonical Spec

Focused on `neuralos.scheduler` and an explicit OS-state type. See [MLIR DefiningDialects/AttributesAndTypes](https://mlir.llvm.org/docs/DefiningDialects/AttributesAndTypes/).

---

## 1. OS state type

### 1.1 High-level intent

The **OS state** is a small, first-class, per-batch control state that the scheduler reads and that `os_state_update` writes. [MLIR LangRef](https://mlir.llvm.org/docs/LangRef/) It must be explicit, strongly typed, and analyzable as a distinct value in the IR, not a generic tensor. [MLIR Toy Ch-7](https://mlir.llvm.org/docs/Tutorials/Toy/Ch-7/)

### 1.2 MLIR type: `!neuralos.os_state`

We define a custom dialect type:

- **Name:** `!neuralos.os_state`.
- **Underlying storage:** a fixed-shape tensor per batch: `tensor<BxD_osxf32>`.
- **Logical layout:** vector of **slots**, each slot has:
  - `name: StringAttr` (e.g. `"task_queue"`, `"focus"`, `"load"`).
  - `size: i64` (number of channels).

We capture this layout as a type parameter, e.g.:

```mlir
// Example OS state: three slots
!neuralos.os_state<[
  #neuralos.slot<"task_queue", 32>,
  #neuralos.slot<"focus", 16>,
  #neuralos.slot<"resource_load", 8>
]>
```

Where:

- Total `D_os = sum(slot.size)`.
- The physical representation is always `tensor<BxD_osxf32>`, but the type carries named slots for analysis and verification. [MLIR DefiningDialects/AttributesAndTypes](https://mlir.llvm.org/docs/DefiningDialects/AttributesAndTypes/)

In the initial implementation, you can:

- Keep `B` (batch) dynamic and only fix `D_os` from the slot list.
- Provide helpers to map a slot to a contiguous channel range in the underlying tensor.

### 1.3 Invariants for `!neuralos.os_state`

1. **Shape compatibility**
   - Any SSA value of type `!neuralos.os_state<Slots>` must correspond to a tensor with last-dim size `D_os = sum(Slots.size)` at runtime.
   - Ops consuming/producing OS state must preserve the same slot list (no structural changes without an explicit transform op).

2. **Single-writer per step**
   - In a single block step, each OS state value has at most one **updating** op (`neuralos.os_state_update`) in its use-def chain.
   - Copies/forwards are allowed (e.g. passing OS state through), but there is a unique logical writer per step.

3. **Batch consistency**
   - Batch size `B` of OS state matches batch size of tokens for the same block step.

A simple verifier in the dialect walks uses of `!neuralos.os_state` and checks that only allowed writers exist and all readers see a compatible layout. [discourse.llvm – custom type](https://discourse.llvm.org/t/create-a-custom-type/1415)

### 1.4 Design decision: OS metaphor (push vs pull back)

The spec and Goals/Non-goals must record which of the following is adopted for v1.

- **Push the metaphor:** Treat slot names as real semantics and give per-slot update invariants the verifier can check.
  - **`task_queue` slot:** Update rule approximates FIFO, e.g. shift-and-append with decay.
  - **`focus` slot:** Exponential moving average over recent hidden features.
  - **`resource_load` slot:** Bounded accumulator with leak (e.g. utilization gauge).
  - State these as per-slot invariants (e.g. norm bounds, monotonicity ranges) and allow the verifier to check them.
- **Pull back:** Rename to **“named state partitions”** in the spec. Keep them as fixed index ranges with no implied queue/priority semantics; names are documentation only.

Either way, the choice is explicit in this spec and in the plan’s Goals/Non-goals so that downstream (verifier, lowering, docs) is consistent.

---

## 2. `neuralos.scheduler` operation

### 2.1 Purpose

`neuralos.scheduler` computes **routing gates** and a **control signal** from token embeddings and OS state. [MLIR LangRef](https://mlir.llvm.org/docs/LangRef/) It also optionally emits a “cheap path” output for lightweight computation that can bypass SSM/attention. [MLIR Linalg](https://mlir.llvm.org/docs/Dialects/Linalg/)

### 2.2 Signature

**Inputs:**

- `tokens: tensor<BxTxDxf32>` – token embeddings for a block step.
- `os_state: !neuralos.os_state<Slots>` – current OS state, with slot layout as above.

**Outputs:**

- `gates: tensor<BxTxPxf32>` – per-token, per-path gates (last dimension \(P\) = number of paths).
- Path outputs: variadic list of tensors, one per path (e.g. `cheap_out`, `ssm_out`, `attn_out`, …). Semantically they are `path[0..P-1]`; named roles like cheap/dense/attn/moe/retrieval are documentation conventions, not type-level. All path outputs have shape compatible with token stream (e.g. `tensor<BxTxDxf32>` or path-specific reduced shapes).
- `control: tensor<BxTxCxf32>` – control signal for `os_state_update`. \(C\) is tied to OS state layout (see §2.10).

**Attributes:**

- `paths: i32` – number of paths \(P\). Gate tensor shape is \(B \times T \times P\).
- `routing_mode: EnumAttr` – one of `inference`, `train_soft`, `train_hard` (see §2.5). Training lowerings may introduce auxiliary ops (e.g. Gumbel noise, temperature) that are elided or frozen at inference.
- `control_dim: i64` – equal to \(C\) (defaults and justification in §2.10).
- Optional: `gate_temperature: f32`, `gate_bias: DenseElementsAttr` for initialization/debug.

Example textual form:

```mlir
%gates, %cheap_out, %control =
  neuralos.scheduler
    %tokens, %os_state
    { paths = 3, routing_mode = #neuralos.routing<inference>,
      control_dim = 32, gate_temperature = 1.0 }
  : (tensor<?x?x?xf32>, !neuralos.os_state<[#neuralos.slot<"task_queue", 32>, ...]>)
    -> (tensor<?x?x3xf32>, tensor<?x?x?xf32>, tensor<?x?x32xf32>)
```

Adding a new path later is “increase \(P\) and plug in another sub-block”, not a dialect redesign.

### 2.3 Shapes and layout

Let:

- \(tokens \in \mathbb{R}^{B \times T \times D}\).
- \(os\_state \in \mathbb{R}^{B \times D_{os}}\) (physical representation of `!neuralos.os_state`).
- **Outputs:**
  - \(gates \in \mathbb{R}^{B \times T \times P}\) (gate tensor; \(P\) from `paths` attribute).
  - Path outputs: one tensor per path (e.g. cheap path `tensor<B \times T \times D>\) or path-specific shapes).
  - \(control \in \mathbb{R}^{B \times T \times C}\).

Path index \(p \in \{0, \ldots, P-1\}\) corresponds to a fixed ordering (e.g. 0=SSM, 1=attention, 2=cheap); named roles are documentation. [MLIR LangRef](https://mlir.llvm.org/docs/LangRef/)

### 2.4 Reference equations

You can refine these later; the goal is to have **one unambiguous reference implementation** that your lowering matches.

1. **State conditioning**

   Project OS state into token feature space and control space:

   \[
   s' = \text{LN}_s(W_s \cdot os\_state + b_s)
   \]

   with \(W_s \in \mathbb{R}^{D_{os} \times D}\), \(b_s \in \mathbb{R}^{D}\). Broadcast over time: \(S \in \mathbb{R}^{B \times T \times D}\) with \(S_{b,t,:} = s'_b\).

2. **Combined token features**

   \[
   h = \text{LN}_h(tokens + S)
   \]

   where LN is layer norm over the last dimension.

3. **Gate logits and normalization**

   Compute gate logits \(G \in \mathbb{R}^{B \times T \times P}\):

   \[
   \ell^{gate} = h W_g + b_g
   \]

   where \(W_g \in \mathbb{R}^{D \times P}\), \(b_g \in \mathbb{R}^{P}\). Normalization and routing behaviour depend on `routing_mode` (see §2.5). For inference with standard softmax:

   \[
   gates_{b,t,p} = \frac{\exp(\ell^{gate}_{b,t,p} / \tau)}{\sum_{p'} \exp(\ell^{gate}_{b,t,p'} / \tau)}
   \]

   where \(p \in \{0, \ldots, P-1\}\) and \(\tau = gate\_temperature\). [MLIR LangRef](https://mlir.llvm.org/docs/LangRef/)

4. **Cheap path**

   Cheap features:

   \[
   z = \sigma(h W_c + b_c)
   \]

   with \(W_c \in \mathbb{R}^{D \times D}\), \(b_c \in \mathbb{R}^{D}\), \(\sigma\) an element-wise nonlinearity (e.g. GELU). Then:

   \[
   cheap\_out = gates_{[:,:,p_{cheap}]} \odot z
   \]

   where \(p_{cheap}\) is the path index for the cheap path (e.g. 2 in a 3-path layout); the gate slice is broadcast along D.

5. **Control signal**

   Control logits:

   \[
   \ell^{ctrl} = h W_{ctrl} + b_{ctrl}
   \]

   with \(W_{ctrl} \in \mathbb{R}^{D \times C}\), \(b_{ctrl} \in \mathbb{R}^{C}\). Optional normalization (e.g., tanh):

   \[
   control = \tanh(\ell^{ctrl})
   \]

This is deliberately simple: a two-layer MLP over token + broadcast OS state, producing gates and control with clear semantics. [Lei Mao – Linalg](https://www.lei.chat/posts/mlir-linalg-dialect-and-patterns/)

### 2.5 Training-time routing

Gate logits are represented as a tensor \(G \in \mathbb{R}^{B \times T \times P}\). The op has a **mode flag** `routing_mode`: `inference` | `train_soft` | `train_hard`.

- **`inference`:** Standard softmax over \(P\); use the resulting weights for weighted mixing of path outputs. No gradient flow (forward-only).
- **`train_soft`:** Same as inference from a forward perspective: softmax over \(P\) and weighted mixing of all paths. Gradients flow through the soft weights; this matches the current design and is the default for end-to-end differentiable training without hard routing.
- **`train_hard`:** Straight-through estimator (STE) semantics. **Forward:** use a discrete choice (e.g. argmax over perturbed logits, e.g. Gumbel-softmax with temperature → 0) to pick a one-hot route. **Backward:** gradients use the underlying softmax probabilities so the router remains trainable. The MLIR op carries the `routing_mode` attribute; training lowerings are allowed to introduce auxiliary ops (e.g. Gumbel noise, temperature) that are elided or frozen at inference.

This gives an explicit, verifiable contract for gradient flow through “hard” routing. See [Emergent Mind – Gumbel-softmax / ST-GS](https://www.emergentmind.com/topics/gumbel-softmax-based-straight-through-estimators-st-gs) and [Fabian Fuchs – Gumbel](https://fabianfuchsml.github.io/gumbel/).

### 2.6 Op invariants

The verifier for `neuralos.scheduler` enforces:

- **Rank/shape constraints:** `tokens` is rank-3; same `B` for tokens and OS state. Gate tensor last dimension is \(P\); path output count and shapes match `paths`; control last dimension is \(C\).
- **OS state type consistency:** `os_state` must be of a `!neuralos.os_state<Slots>` type, and lowering knows how to materialize its tensor view.
- **Gate normalization:** Optionally, a numeric checker in tests verifies that `gates` sum to 1 over the last dimension within a tolerance.

### 2.7 Lowering sketch

Lowering `neuralos.scheduler` to `linalg`/`tensor`/`arith` is a purely mechanical expansion of the equations above: [MLIR Linalg](https://mlir.llvm.org/docs/Dialects/Linalg/)

- Extract OS state tensor from `!neuralos.os_state`.
- Use `linalg.matmul` / `linalg.generic` and `arith` ops for affine parts.
- Implement LN, softmax and tanh via standard patterns or calls into existing utility ops if you have them.

The key rule: no extra optimization logic here; this is the **canonical expansion** that your equivalence tests lock in.

### 2.8 Cost model

Each path must have a defined cost so the scheduler can be trained or regularized to choose paths under a cost budget. The **cheap path** must be strictly cheaper than the heavy paths in at least one of:

- **Reduced hidden size:** \(d_{\text{cheap}} \ll d_{\text{model}}\) (narrower MLP or projection).
- **No KV-cache read/write:** pure state update, no attention (avoids cache I/O).
- **Lower precision or group-wise quantization** for the cheap path only.
- **Fewer FFN layers or rank-reduced projection** (e.g. low-rank linear).

Define a simple **cost metric**, e.g. “FLOPs + KV-bytes moved”. The scheduler is trained/regularized to choose paths under this cost; profiling and ablation use this metric.

**First prototype (v1) decision:** adopt one concrete cheapness lever and document it in the plan, e.g. “cheap path: 0.25× MLP width and no KV cache updates.” Other levers can be added later.

### 2.9 Variable sequence lengths and KV cache

- Let \(T_{\text{in}}\) be the current step’s token count and \(T_{\text{cache}}\) the KV cache length. Inputs use \(T_{\text{in}}\); KV tensors use \(T_{\text{cache}}\); outputs can grow the cache to \(T_{\text{cache}}' = T_{\text{cache}} + T_{\text{in}}\) (or per policy).
- The **scheduler** is length-agnostic (it operates on token features and OS state; it does not depend on sequence length). The **attention path** must implement a window/cache policy (sliding window, chunked KV, etc.), similar to Jamba/Griffin-style hybrids that mix attention with recurrent/SSM blocks (see [SSM–Transformer hybrids guide](https://n1o.github.io/posts/ssm-transformer-hybrids-guide/)).
- In the MLIR op: either (a) pass cache tensors explicitly in the block/scheduler signature, or (b) state that KV/cache semantics are delegated to the underlying attention primitive and only referenced by symbol. A short paragraph in the spec that “KV/cache semantics are delegated to the attention op spec” is sufficient for v1.

### 2.10 Control-signal dimensionality \(C\)

Tie \(C\) to OS state layout instead of a fixed 16–64:

- **Option A:** \(C = D_{\text{os}}\) (full-bandwidth control).
- **Option B:** \(C = k \times \text{num\_slots}\) with small \(k\) (e.g. 4–8), so control scales with state complexity but does not dominate it.

Document default values for v1, e.g. `num_slots = 4`, \(k = 8\) \(\Rightarrow\) \(C = 32\). Treat \(C\) as a tunable hyperparameter, not a magic constant.

---

*Optional follow-up:* A matching spec for `neuralos.os_state_update` that consumes this `control` and the same `!neuralos.os_state` type can be added later in a separate section or doc.
