# NeuralOS MLIR Dialect: Restart Plan

**Principle:** Keep it tiny, semantic, and MLIR-native.

The best way to restart is to aim for a **small, sharp, MLIR-based NeuralOS dialect as your canonical IR**, and treat everything else (PyTorch, ONNX, runtimes) as frontends/backends around it.

---

## Goals and non-goals

- **Goals:** Express NeuralOS concepts (blocks, schedulers, OS state) directly in the IR; lower cleanly to existing MLIR/LLVM/ONNX; keep the dialect small and finishable; support verifiable routing and state-update contracts.
- **Non-goals:** Replacing linalg/ONNX; supporting every possible path shape without spec updates; opaque “black box” routing (semantics and path usage are visible to the compiler).
- **OS metaphor:** The choice between **pushing** the OS metaphor (real slot semantics: task_queue ≈ FIFO, focus ≈ EMA, resource_load ≈ leaky gauge; verifier-checkable per-slot invariants) and **pulling back** to neutral “named state partitions” (fixed index ranges, names as documentation only) is recorded in [NEURALOS_SCHEDULER_SPEC.md](NEURALOS_SCHEDULER_SPEC.md) §1.4. Adopt one for v1 and keep spec and verifier consistent.
- **Cost model (v1):** For the first prototype, the cheap path is defined as **0.25× MLP width and no KV cache updates**. Profiling and scheduler regularization use the cost metric (FLOPs + KV-bytes moved) from the spec §2.8.

---

## What “best” means

- **Expresses NeuralOS concepts directly** (blocks, schedulers, OS state), not just math.
- **Lowers cleanly** to existing MLIR/LLVM/ONNX ecosystems, so you inherit optimizations and backends.
- **Small enough** that you can actually finish and evolve it.

Use MLIR as the infrastructure (SSA, passes, codegen) and design one **NeuralOS dialect** that sits at the top of a multi-level IR stack.

---

## Phase 1 (3–4 weeks): Spec + dialect bootstrap

See [NEURALOS_SCHEDULER_SPEC.md](NEURALOS_SCHEDULER_SPEC.md) for shapes, equations, invariants, training-time routing, cost model, and KV/cache delegation. *A 2-week Phase 1 is retained as an aspirational stretch goal.*

### Week 1: Custom types, attributes, basic ops

- **Types:** `!neuralos.os_state` (slot layout), control-signal semantics.
- **Attributes:** `paths` (i32), `routing_mode` (inference | train_soft | train_hard), and existing scheduler attributes.
- **Basic ops:** Skeleton for `neuralos.scheduler` with parameterized path count \(P\) and gate shape \(B \times T \times P\).

### Week 2: Parser, printer, verifier, round-trip

- Parser/printer for the dialect and `!neuralos.os_state`.
- Verifier for rank/shape, gate normalization, OS state consistency.
- Round-trip tests (parse → print → parse).

### Week 3–4: Initial lowerings and training variants

- Lowering stubs to existing attention/MLP primitives.
- Simple training-time variants (e.g. Gumbel/temperature auxiliary ops as in spec §2.5), elided or frozen at inference.

### Deliverable 1: Mathematical spec for `neuralos.scheduler` and OS state type

- **Shapes and equations:** Inputs \(tokens \in \mathbb{R}^{B \times T \times D}\), \(os\_state \in \mathbb{R}^{B \times D_{os}}\). Output: gate tensor \(g \in \mathbb{R}^{B \times T \times P}\) (P from `paths` attribute), variadic path outputs, and control. Normalization and training semantics in spec (§2.4–2.5).
- **`!neuralos.os_state` type:** Distinct dialect type (e.g. wrapper over `tensor<B×D_os×f32>` with slot layout) so invariants and analysis key off it, not a raw tensor.

### Deliverable 2: Minimal dialect skeleton

- Implement the dialect with:
  - **`neuralos.scheduler`** op via ODS/TableGen: inputs, results, attributes (`paths`, `routing_mode`, …), assembly format.
  - Skeletal **`!neuralos.os_state`** type with parser/printer.
- You can make `neuralos.ssm_core` the first *lowered* op later; scheduler and state types being explicit from day one is what makes this a NeuralOS IR, not just “another SSM dialect.”

**Phase 1 goal:** I can write a `.mlir` file with `neuralos.scheduler` (parameterized \(P\), `routing_mode`) and an explicit `!neuralos.os_state` value that parses, prints, and type-checks.

---

## Phase 2 (Week 3–4): Lowering and equivalence

### Order

1. **First:** Lower `neuralos.ssm_core` to linalg/tensor/arith and hook it to your PyTorch SSM as described.
2. **In parallel:** Add a trivial lowering for `neuralos.scheduler` to basic `linalg.generic` + `arith` (literally implementing the gate equations); don't optimize yet.

### Equivalence harness

Build the equivalence harness around **two** primitives:

- **SSM core numerics.**
- **Scheduler numerics** (gates/control) for random token/state inputs.

That way, by end of Phase 2 you have: "NeuralOS numerics (SSM + scheduler) are correct," not just SSM.

**Phase 2 goal:** NeuralOS numerics (SSM + scheduler) are correct.

---

## Phase 3 (Week 5–6): Block, OS state, and flow

### Refinements

- **`neuralos.os_state_update`:** Make it operate on `!neuralos.os_state`, not bare tensors. Enforce invariants in the verifier (matching shapes, no fan-out of mutable state unless explicitly allowed).
- **`neuralos.block`:** Implement as a **single region op** that contains calls to `neuralos.ssm_core`, `neuralos.local_attention`, `neuralos.scheduler`, `neuralos.os_state_update`, plus any cheap path.
- **End-to-end test:** Prefer one step of a **single block**, matching a PyTorch implementation that manually instantiates the same wiring. Use the same random seeds and batched inputs to compare outputs and next-state. That keeps the IR structural while still being analyzable as “a sequence of blocks over token streams and state.”

**Phase 3 goal:** Your IR can represent exactly what NeuralOS is *conceptually* and prove it matches the reference implementation.

---

## Phase 4 (Month 3+): Passes, frontends, and UX

**Structural vs computational:** Distinguish "structural" vs "computational" dialects: NeuralOS is structural/semantic, while linalg/arith are computational. Do analyses on NeuralOS ops and treat lowering as the phase boundary.

### 7. Add domain-specific analysis/optimization passes

Examples of things a generic IR can’t easily do:

- Inspect scheduler gates across layers to compute “OS attention” profiles.
- Fuse SSM+attention+CheapPath under known gate patterns.
- Verify OS state invariants (e.g., no illegal fan-out of mutable state).

Implement these as MLIR passes that operate on `neuralos.*` ops before lowering.

**First two analysis passes** for immediate value:

1. **State-flow verifier:** Walks uses of `!neuralos.os_state` and checks you only have allowed update topologies.
2. **Scheduler-profile pass:** Aggregates gate statistics over blocks (for debugging and research) before lowering.

### 8. Add frontends and backends around the IR

- **Frontend:** For the PyTorch frontend, you can start by literally emitting MLIR textual assembly for small configs; several projects (e.g. Catalyst) do this early before building a serious importer.
- **Backends:**
  - NeuralOS → `linalg` → LLVM/SPIR-V for native runtimes.
  - Optional: NeuralOS → ONNX dialect → ONNX for compatibility.

### 9. Polish developer experience

- Pretty printer that shows blocks and OS state in a human-readable way.
- Minimal runtime that can load a compiled NeuralOS module and expose `step()` and `run()` APIs.
- Documentation with small examples of NeuralOS programs at the IR level.

**Phase 4 goal:** Your IR becomes “hands down the best” for your niche: not because it replaces MLIR/ONNX, but because it captures NeuralOS semantics cleanly and still plugs into those ecosystems.

---

## Guardrails (avoid science-project collapse)

| Rule | Detail |
|------|--------|
| **Keep the dialect small** | Maybe 5–10 ops total. No more unless you prove you need them. |
| **Reuse upstream** | Use upstream dialects and passes aggressively; don’t duplicate `linalg`/`tensor`/`vector` functionality. |
| **Feature discipline** | Every new feature must come with: (1) a spec update, (2) at least one equivalence test vs a reference implementation. |

---

## Related work

Hybrid architectures mix SSMs, attention, and routing: **Jamba** (SSM + attention + MoE), **Griffin** (gated recurrence + local attention), and similar SSM/attention hybrids (e.g. [Griffin arxiv](https://arxiv.org/html/2402.19427v1)). NeuralOS differs by elevating routing and state management into **explicit, named OS-like slots** with **compiler-checkable invariants** and an MLIR dialect that can verify path usage and state-update contracts. What NeuralOS can express that these do not: **verifiable global invariants over routing**, **explicit OS state** as a first-class type, and **per-path semantics visible to the compiler** (cost model, training modes, KV/cache delegation) so that analyses and lowerings can reason about the policy surface.

---

## References

- [Emergent Mind – MLIR](https://www.emergentmind.com/topics/multi-level-intermediate-representation-mlir)
- [Cornell CS6120 – MLIR](https://www.cs.cornell.edu/courses/cs6120/2023fa/blog/mlir/)
- [Wikipedia – MLIR](https://en.wikipedia.org/wiki/MLIR_(software))
- [MLIR – Creating a Dialect](https://mlir.llvm.org/docs/Tutorials/CreatingADialect/)
- [PennyLane – Dialects](https://docs.pennylane.ai/projects/catalyst/en/stable/dev/dialects.html)
- [Lei Mao – MLIR codegen dialects](https://www.lei.chat/posts/mlir-codegen-dialects-for-machine-learning-compilers/)
- [Lei Mao – MLIR vector dialect and patterns](https://www.lei.chat/posts/mlir-vector-dialect-and-patterns/)
- [Reddit – MLIR dialect design best practice](https://www.reddit.com/r/Compilers/comments/1ih6khm/mlir_dialect_design_best_practise/)

---

## Flagship op stack: three compounding innovations

Aim for a **stack** of a few compounding flagship ops, not just one. The sweet spot for NeuralOS is three tightly linked innovations in the IR:

| Flagship | Op | Role |
|----------|-----|------|
| **1** | `neuralos.scheduler` | Dynamic, OS‑aware routing (SSM / attention / cheap path + control) |
| **2** | `neuralos.os_state_update` | First‑class OS state with explicit layout and verifiable flow |
| **3** | `neuralos.block` | Macro‑op with policy surface and backend‑aware lowering |

**How they compound:** The block defines a policy surface; the scheduler enforces it token‑by‑token; the OS state op provides the memory that makes the policy intelligent.

### Flagship 1: Scheduler / router op

**`neuralos.scheduler`** jointly:

- **Reads:** token stream + OS state.
- **Produces:** gates/routing over **SSM path**, **attention path**, **cheap path** (richer than generic hybrid SSM–attention gates).
- **Emits:** an updated **control** signal for OS state update.

This gives dynamic, OS‑aware routing that is explicit in the IR.

### Flagship 2: OS state op

**`neuralos.os_state_update`** treats a small OS state as a first‑class object:

- **Explicit type and layout:** e.g. slots for "task queue", "focus window", "resource load".
- **Deterministic update rule** from token features + scheduler (control) signals.
- **Designed for analysis:** state flow can be analyzed and verified in the IR, not only at the math level.

NeuralOS is then a real "stateful system" in the IR, not just a big RNN.

### Flagship 3: Block-level macro‑op with structured fusion

**`neuralos.block`**:

- **Encapsulates:** SSM, attention, scheduler, cheap path, and OS state update in one macro‑op.
- **Policy attributes:** e.g. locality vs globality, latency vs quality tradeoff knobs.
- **Backend lowering:** policy‑aware rewrites to server‑grade, edge, low‑latency realizations while preserving semantics.

This is where "NeuralOS as an OS" is baked in: same high‑level block, different compiled realizations.

---

## Minimal op set (on-paper spec)

Given that, the strongest next move is to **define the actual NeuralOS ops on paper** so you can turn them into an MLIR dialect later. The set below aligns with the flagship stack; primitives like `ssm_core` and `local_attention` support the block.

### Primitives (used inside the block)

- **`neuralos.ssm_core`**
  - **Inputs:** `x: tensor<BxTxD>`, `ssm_state: tensor<BxD_ssm>`
  - **Outputs:** `y: tensor<BxTxD>`, `ssm_state_out: tensor<BxD_ssm>`

- **`neuralos.local_attention`**
  - **Inputs:** `x: tensor<BxTxD>`, attributes for window size, heads, etc.
  - **Outputs:** `y: tensor<BxTxD>`

### Flagship 1: Scheduler

- **`neuralos.scheduler`**
  - **Inputs:** `tokens: tensor<BxTxD>`, `os_state: !neuralos.os_state<Slots>` (or compatible typed OS state)
  - **Outputs:** Gate tensor \(g \in \mathbb{R}^{B \times T \times P}\) (`paths` attribute; normalization and training modes in spec), variadic path outputs (e.g. cheap, dense, attn, …), `control: tensor<BxTxC>` (C tied to OS state layout, see spec §2.10).
  - **Attributes:** `paths: i32`, `routing_mode: inference | train_soft | train_hard`; training lowerings may introduce Gumbel/temperature ops elided at inference. KV/cache semantics are delegated to the attention op spec.
  - See [NEURALOS_SCHEDULER_SPEC.md](NEURALOS_SCHEDULER_SPEC.md) for equations, shapes, cost model, and variable-length/KV cache.

### Flagship 2: OS state

- **`neuralos.os_state_update`**
  - **Inputs:** `tokens: tensor<BxTxD>`, `control: tensor<BxTxD_control>` (from scheduler), `os_state: !neuralos.os_state<Slots>`
  - **Outputs:** `os_state_out: !neuralos.os_state<Slots>` (same type/layout as input)
  - **Invariant:** deterministic update rule; verifier enforces invariants (matching shapes, allowed update topologies). Layout (e.g. slots for task queue, focus window, resource load) is part of the type so that state flow is analyzable in the IR.

### Flagship 3: Block

- **`neuralos.block`**
  - **Inputs:** `tokens: tensor<BxTxD>`, `ssm_state: tensor<BxD_ssm>`, `os_state: !neuralos.os_state<Slots>` (or `tensor<BxD_os>` where compatible)
  - **Outputs:** `out_tokens: tensor<BxTxD>`, `ssm_state_out: tensor<BxD_ssm>`, `os_state_out: !neuralos.os_state<Slots>`
  - **Attributes:** policy knobs (e.g. locality vs globality, latency vs quality); used by policy‑aware lowering. Block uses scheduler with parameterized \(P\); adding a new path is “increase P and plug in another sub-block” (see spec).

---

## Next step

When you define `neuralos.scheduler` precisely, define its **associated OS state type and invariants** in the same short spec doc so you avoid revisiting shapes and control semantics later.

1. **Step 1:** Precise equations + `!neuralos.os_state` type.
2. **Step 2:** Spec for `neuralos.os_state_update` and `neuralos.block` building on that.
3. **Step 3:** Implement `neuralos.scheduler` and `!neuralos.os_state` in the dialect as your **Phase 1.2 milestone**, then follow with `ssm_core`.
