# NeuralOS Prototype Plan

**Goal:** Validate the core architecture in PyTorch before building any compiler infrastructure. Prove dynamic routing between SSM, attention, and a cheap path beats fixed interleaving at the same compute budget.

**Target:** Best quality-per-FLOP at 150M–1B scale.

---

## Phase 0: Baselines (Days 1–3)

Build and train minimal baselines on the same data, same tokenizer, same token budget. Everything else is meaningless without these.

### Models

| Baseline | Description |
|----------|-------------|
| **Pure Mamba-2** | Standard Mamba-2 stack, no attention. Same param count. |
| **Pure Transformer** | Standard pre-norm transformer, same param count. |
| **Fixed Hybrid** | Jamba-style: every Nth layer is attention, rest are SSM. No learned routing. |

### Setup

- **Scale:** 150M params initially. Bump to 350M–1B once the architecture is validated.
- **Data:** FineWeb-Edu, RedPajama, or whatever you have access to. ~10B tokens for 150M scale.
- **Tokenizer:** Use an existing one (GPT-NeoX, Llama, Mistral). Don't waste time here.
- **Training:** Standard setup — AdamW, cosine schedule, warmup. Use the same hyperparameters across all baselines to keep comparisons fair.
- **Eval:** Track val loss continuously. Run Hellaswag, ARC-Easy, PIQA, WinoGrande at checkpoints. These are cheap and signal whether the model is learning.

### Deliverable

A training script and eval harness that can run any of the baselines and produce comparable numbers. This is the foundation everything else builds on.

---

## Phase 1: Core Routing Prototype (Days 4–10)

### 1.1 The Router

The router is a small network that takes token embeddings and produces per-token gates over {SSM, attention, cheap}. This is the central bet.

```python
class Router(nn.Module):
    def __init__(self, d_model, n_paths=3, temperature=1.0):
        super().__init__()
        self.proj = nn.Linear(d_model, n_paths)
        self.temperature = temperature

    def forward(self, x):
        # x: (B, T, D)
        logits = self.proj(x) / self.temperature
        gates = F.softmax(logits, dim=-1)
        return gates  # (B, T, n_paths)
```

Start simple. No OS state yet. Just token features → gates. Add complexity only when this works.

### 1.2 The Block

Each block computes all three paths and blends them using soft gates during training:

```python
class NeuralOSBlock(nn.Module):
    def __init__(self, d_model, ...):
        super().__init__()
        self.ssm = Mamba2Layer(d_model)
        self.attn = LocalAttention(d_model, window_size=512)
        self.cheap = CheapPath(d_model)
        self.router = Router(d_model)
        self.norm = RMSNorm(d_model)

    def forward(self, x, ssm_state=None):
        x_norm = self.norm(x)
        gates = self.router(x_norm)  # (B, T, 3)

        y_ssm, ssm_state = self.ssm(x_norm, ssm_state)
        y_attn = self.attn(x_norm)
        y_cheap = self.cheap(x_norm)

        # Soft mix: all paths computed, weighted blend
        y = (gates[..., 0:1] * y_ssm +
             gates[..., 1:2] * y_attn +
             gates[..., 2:3] * y_cheap)

        return x + y, ssm_state
```

**Important:** During training, all three paths run for every token (soft mixing). The compute savings come at inference via hard routing. This is how MoE training works — same principle.

### 1.3 The Cheap Path — Make It Actually Cheap

The cheap path must be meaningfully cheaper than SSM or attention. Otherwise there's no point routing tokens to it.

```python
class CheapPath(nn.Module):
    def __init__(self, d_model, ratio=4):
        super().__init__()
        # Small hidden dim: D -> D/ratio -> D
        self.net = nn.Sequential(
            nn.Linear(d_model, d_model // ratio),
            nn.GELU(),
            nn.Linear(d_model // ratio, d_model),
        )
```

At D=1024, ratio=4: this is a 1024→256→1024 MLP. ~0.5M params vs ~3M for an attention layer. That's the kind of gap that makes routing worthwhile.

### 1.4 Load Balancing Loss

Without this, the router will collapse — sending all tokens to one path. Borrowed directly from MoE literature (Switch Transformer):

```python
def load_balance_loss(gates, alpha=0.01):
    # gates: (B, T, P)
    # Encourage uniform distribution across paths
    frac = gates.mean(dim=(0, 1))          # (P,) avg gate per path
    target = torch.ones_like(frac) / frac.shape[0]
    return alpha * F.mse_loss(frac, target)
```

Add this to the training loss. Tune alpha — too high forces uniform routing (defeating the purpose), too low allows collapse.

### Deliverable

A NeuralOS model that trains, converges, and produces val loss + benchmark numbers comparable to the baselines. Gate distributions are logged per layer.

---

## Phase 2: Persistent State (Days 11–17)

Only start this after Phase 1 routing works and shows promise.

### 2.1 The State

A small learned vector per batch element that persists across block steps and informs routing:

```python
class PersistentState(nn.Module):
    def __init__(self, d_model, d_state=64):
        super().__init__()
        self.proj_in = nn.Linear(d_state, d_model)
        self.update = nn.GRUCell(d_model, d_state)

    def condition(self, x, state):
        # Broadcast state into token space
        s = self.proj_in(state).unsqueeze(1)  # (B, 1, D)
        return x + s

    def step(self, x, state):
        # Summarize tokens and update state
        summary = x.mean(dim=1)  # (B, D) — simple pooling
        state = self.update(summary, state)
        return state
```

**Keep it tiny.** 32–128 dims. If it's too big, it's just a second SSM state. The value is that it captures slow-moving context (topic, difficulty, domain) that the per-token SSM state doesn't.

### 2.2 State-Conditioned Routing

Feed the persistent state into the router:

```python
class StateAwareRouter(nn.Module):
    def __init__(self, d_model, d_state, n_paths=3, temperature=1.0):
        super().__init__()
        self.proj = nn.Linear(d_model + d_state, n_paths)
        self.temperature = temperature

    def forward(self, x, state):
        # x: (B, T, D), state: (B, d_state)
        state_broadcast = state.unsqueeze(1).expand(-1, x.size(1), -1)
        combined = torch.cat([x, state_broadcast], dim=-1)
        logits = self.proj(combined) / self.temperature
        return F.softmax(logits, dim=-1)
```

### 2.3 What to Measure

- **Does adding state improve val loss vs stateless routing?** If not, cut it.
- **Does the state change meaningfully across steps?** Log state norm, cosine similarity between consecutive states. If it flatlines, it's not learning anything.
- **Does state-conditioned routing differ from unconditioned?** Compare gate distributions with and without state. If they're the same, the state isn't contributing to routing decisions.

### Deliverable

Ablation results: stateless routing vs state-conditioned routing. Clear answer on whether persistent state helps.

---

## Phase 3: Inference Efficiency (Days 18–24)

### 3.1 Hard Routing at Inference

During training, all paths run (soft mixing). At inference, route each token to its top-1 path:

```python
def forward_inference(self, x, ssm_state=None):
    gates = self.router(self.norm(x))           # (B, T, 3)
    path_idx = gates.argmax(dim=-1)             # (B, T)

    y = torch.zeros_like(x)
    mask_ssm = (path_idx == 0)
    mask_attn = (path_idx == 1)
    mask_cheap = (path_idx == 2)

    if mask_ssm.any():
        y[mask_ssm] = self.ssm(x[mask_ssm], ...)
    if mask_attn.any():
        y[mask_attn] = self.attn(x[mask_attn], ...)
    if mask_cheap.any():
        y[mask_cheap] = self.cheap(x[mask_cheap], ...)

    return x + y, ssm_state
```

This is where the actual speedup happens. If 40% of tokens go to the cheap path, you skip SSM/attention for nearly half the tokens.

**Caveat:** The indexing and masking above is simplified. Real implementation needs to handle the fact that SSM is sequential (you can't just skip tokens in the middle of a sequence) and attention needs contiguous windows. This is the hardest engineering in the whole project. Options:
- Run SSM on all tokens but only use its output where `mask_ssm` is true (simpler, less speedup).
- Batch tokens by path and run each path on its batch (faster, more complex bookkeeping).

### 3.2 Temperature Annealing

Train with temperature=1.0 (soft gates). During final training phase, anneal temperature downward (0.5 → 0.1) to sharpen gates toward hard routing. This closes the gap between training (soft) and inference (hard).

### 3.3 Benchmarks That Matter

| Metric | What it proves |
|--------|---------------|
| Perplexity at N tokens trained | Quality |
| Hellaswag / ARC / PIQA | Downstream quality |
| Tokens/sec at inference (batch=1) | Latency |
| Tokens/sec at inference (batch=32) | Throughput |
| Peak memory at 4K / 16K / 64K context | Long-context viability |
| FLOP-normalized perplexity | The real target: quality per compute |

### Deliverable

Inference benchmarks showing NeuralOS gets equal quality at fewer FLOPs (or better quality at equal FLOPs) compared to baselines.

---

## Phase 4: Scale and Publish (Days 25–35)

### 4.1 Scale Up

If 150M results are positive:
- Train at 350M and 1B.
- Confirm the routing advantage holds (or grows) with scale. If it shrinks, the idea doesn't scale and that's important to know.

### 4.2 Ablation Table

| Config | Val Loss | HSwag | FLOPs/token | Tokens/sec |
|--------|----------|-------|-------------|------------|
| Pure Mamba-2 | — | — | — | — |
| Pure Transformer | — | — | — | — |
| Fixed Hybrid | — | — | — | — |
| NeuralOS (no state) | — | — | — | — |
| NeuralOS (with state) | — | — | — | — |
| NeuralOS (hard routing) | — | — | — | — |

This table is the entire paper.

### 4.3 Release

- Model weights on HuggingFace.
- Training code on GitHub.
- Short paper / technical report with the ablation table and gate distribution analysis.
- If the MLIR dialect still makes sense after all this, revisit it with a validated architecture.

---

## Key Decisions (Decide Before Writing Code)

| Decision | Recommendation | Rationale |
|----------|---------------|-----------|
| Number of paths | Start with 3 (SSM, attn, cheap). Make it configurable. | Can extend later without redesign. |
| Routing granularity | Per-token | Per-layer is too coarse, per-head is too complex for a prototype. |
| Attention type | Sliding window (512–1024) | Local attention is cheap enough to be practical, complements SSM's global state. |
| SSM variant | Mamba-2 | Best current SSM. Use the reference implementation. |
| Cheap path hidden dim | D/4 or D/8 | Must be meaningfully cheaper than the other paths. |
| Persistent state dim | 64 | Start small, ablate up to 128. |
| Persistent state update | GRU cell on mean-pooled tokens | Simple, proven, cheap. |
| Load balance loss weight | 0.01 | Tune on first runs. |
| Gate temperature | 1.0 training, anneal to 0.1 | Standard approach from Gumbel-softmax literature. |
| Framework | PyTorch + FlashAttention + Mamba kernel | Don't reinvent low-level kernels. |

---

## What Would Kill the Project

Be honest about these and check early:

1. **Router collapses** despite load balancing → all tokens go to one path. Try expert-choice routing (tokens don't choose paths; paths choose tokens) as a fallback.
2. **Soft-to-hard gap** is too large → model trained with soft mixing degrades badly with hard routing. Increase annealing duration or try straight-through estimators.
3. **Routing doesn't beat fixed interleaving** → the overhead of a router per layer costs more than the savings from adaptive allocation. If this happens at 150M, try at 350M — routing benefits may emerge with scale.
4. **Persistent state doesn't help** → cut it. Ship the stateless routing version. Adaptive routing alone may be enough.

---

## File Structure

```
neuralos/
├── model/
│   ├── block.py          # NeuralOSBlock with router, paths, mixing
│   ├── router.py         # Router and StateAwareRouter
│   ├── cheap_path.py     # CheapPath MLP
│   ├── state.py          # PersistentState
│   └── model.py          # Full NeuralOS model (stack of blocks + embeddings + head)
├── baselines/
│   ├── mamba2.py         # Pure Mamba-2 baseline
│   ├── transformer.py    # Pure transformer baseline
│   └── fixed_hybrid.py   # Jamba-style fixed interleaving
├── train.py              # Training loop (shared across all models)
├── eval.py               # Eval harness (perplexity + benchmarks)
├── config.py             # Model configs for 150M, 350M, 1B scales
└── requirements.txt
```
