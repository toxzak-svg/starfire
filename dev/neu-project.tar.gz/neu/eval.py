"""
Evaluation harness — val loss, perplexity, and lm-evaluation-harness benchmarks.

Usage:
    python -m neu.eval --checkpoint checkpoints/neu_150m_step50000.pt --model neu
    python -m neu.eval --checkpoint checkpoints/neu_150m_step50000.pt --model neu --benchmarks hellaswag,arc_easy,piqa,winogrande
"""

import argparse
import math
import json
import os
from contextlib import nullcontext

import torch

from neu.config import ModelConfig, TrainConfig
from neu.data import get_dataloader
from neu.model.model import NeuModel
from neu.baselines.mamba2 import Mamba2Model
from neu.baselines.transformer import TransformerModel
from neu.baselines.fixed_hybrid import FixedHybridModel

MODEL_CLASSES = {
    "neu": NeuModel,
    "mamba2": Mamba2Model,
    "transformer": TransformerModel,
    "fixed_hybrid": FixedHybridModel,
}


@torch.no_grad()
def eval_perplexity(model, loader, device, ctx, max_steps: int = 200):
    model.eval()
    total_loss = 0.0
    total_tokens = 0
    for i, batch in enumerate(loader):
        if i >= max_steps:
            break
        input_ids = batch["input_ids"].to(device)
        targets = batch["targets"].to(device)
        with ctx:
            out = model(input_ids, targets=targets)
        ce = out.get("ce_loss", out["loss"])
        n_tokens = (targets != -1).sum().item()
        total_loss += ce.item() * n_tokens
        total_tokens += n_tokens
    avg_loss = total_loss / max(total_tokens, 1)
    return avg_loss, math.exp(min(avg_loss, 20))


@torch.no_grad()
def eval_gate_distribution(model, loader, device, ctx, max_steps: int = 100):
    """Collect gate statistics across the eval set (Neu model only)."""
    model.eval()
    gate_sums = None
    n = 0
    for i, batch in enumerate(loader):
        if i >= max_steps:
            break
        input_ids = batch["input_ids"].to(device)
        with ctx:
            out = model(input_ids)
        if "gates" not in out:
            return None
        for layer_idx, gates in enumerate(out["gates"]):
            mean_g = gates.detach().float().mean(dim=(0, 1))  # (P,)
            if gate_sums is None:
                gate_sums = [torch.zeros_like(mean_g) for _ in out["gates"]]
            gate_sums[layer_idx] += mean_g
        n += 1

    if gate_sums is None or n == 0:
        return None

    result = {}
    for i, gs in enumerate(gate_sums):
        avg = gs / n
        result[f"layer_{i}"] = {
            "ssm": avg[0].item(),
            "attn": avg[1].item(),
            "cheap": avg[2].item(),
        }
    return result


def run_lm_eval(model, tokenizer_name: str, benchmarks: list, device: str, batch_size: int = 16):
    """Run lm-evaluation-harness benchmarks."""
    try:
        import lm_eval
        from lm_eval.models.huggingface import HFLM
    except ImportError:
        print("lm-eval not installed. Run: pip install lm-eval")
        return None

    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)

    class NeuLMWrapper(HFLM):
        def __init__(self, model, tokenizer, device, batch_size):
            self._model = model
            self.tokenizer = tokenizer
            self._device = torch.device(device)
            self._batch_size = batch_size

        @property
        def device(self):
            return self._device

        @property
        def batch_size(self):
            return self._batch_size

    wrapped = NeuLMWrapper(model, tokenizer, device, batch_size)
    results = lm_eval.simple_evaluate(
        model=wrapped,
        tasks=benchmarks,
        batch_size=batch_size,
    )
    return results


def main():
    parser = argparse.ArgumentParser(description="Evaluate Neu or baseline models")
    parser.add_argument("--checkpoint", type=str, required=True)
    parser.add_argument("--model", type=str, default="neu", choices=MODEL_CLASSES.keys())
    parser.add_argument("--benchmarks", type=str, default=None,
                        help="Comma-separated list of lm-eval benchmarks")
    parser.add_argument("--eval_steps", type=int, default=200)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--dtype", type=str, default="bfloat16")
    parser.add_argument("--output", type=str, default=None, help="Save results to JSON")
    args = parser.parse_args()

    device = args.device
    dtype_map = {"float32": torch.float32, "bfloat16": torch.bfloat16, "float16": torch.float16}
    dtype = dtype_map[args.dtype]
    ctx = torch.amp.autocast(device_type="cuda", dtype=dtype) if device == "cuda" else nullcontext()

    # Load checkpoint
    ckpt = torch.load(args.checkpoint, map_location=device, weights_only=False)
    model_cfg = ModelConfig(**ckpt["model_cfg"])
    train_cfg_data = ckpt.get("train_cfg", {})

    model_cls = MODEL_CLASSES[args.model]
    model = model_cls.from_config(model_cfg).to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()

    print(f"Loaded {args.model} from {args.checkpoint} | Params: {model.param_count():,}")

    train_cfg = TrainConfig()
    if "tokenizer" in train_cfg_data:
        train_cfg.tokenizer = train_cfg_data["tokenizer"]
    if "dataset" in train_cfg_data:
        train_cfg.dataset = train_cfg_data["dataset"]
    train_cfg.batch_size = 8

    results = {"model": args.model, "checkpoint": args.checkpoint}

    # Perplexity
    eval_loader = get_dataloader(train_cfg, split="validation")
    val_loss, ppl = eval_perplexity(model, eval_loader, device, ctx, args.eval_steps)
    results["val_loss"] = val_loss
    results["perplexity"] = ppl
    print(f"Val loss: {val_loss:.4f} | Perplexity: {ppl:.2f}")

    # Gate distribution (Neu only)
    if args.model == "neu":
        eval_loader2 = get_dataloader(train_cfg, split="validation")
        gate_stats = eval_gate_distribution(model, eval_loader2, device, ctx)
        if gate_stats:
            results["gate_distribution"] = gate_stats
            print("\nGate distribution:")
            for layer, dist in gate_stats.items():
                print(f"  {layer}: SSM={dist['ssm']:.3f} Attn={dist['attn']:.3f} Cheap={dist['cheap']:.3f}")

    # LM-eval benchmarks
    if args.benchmarks:
        benchmark_list = [b.strip() for b in args.benchmarks.split(",")]
        print(f"\nRunning benchmarks: {benchmark_list}")
        bench_results = run_lm_eval(model, train_cfg.tokenizer, benchmark_list, device)
        if bench_results:
            results["benchmarks"] = bench_results.get("results", {})
            for task, scores in results["benchmarks"].items():
                acc = scores.get("acc_norm", scores.get("acc", "N/A"))
                print(f"  {task}: {acc}")

    # Save results
    if args.output:
        os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
        with open(args.output, "w") as f:
            json.dump(results, f, indent=2)
        print(f"\nResults saved to {args.output}")


if __name__ == "__main__":
    main()
